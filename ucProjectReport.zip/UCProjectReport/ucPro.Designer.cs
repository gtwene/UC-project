﻿namespace UCProject
{
    partial class ucPro
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel3 = new Wisej.Web.Panel();
            this.cbService = new Wisej.Web.ComboBox();
            this.label11 = new Wisej.Web.Label();
            this.panel9 = new Wisej.Web.Panel();
            this.txtTitheRefNo = new Wisej.Web.TextBox();
            this.label10 = new Wisej.Web.Label();
            this.txtTitheNo = new Wisej.Web.TextBox();
            this.label9 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.dtpActualDepositDate = new Wisej.Web.DateTimePicker();
            this.panel8 = new Wisej.Web.Panel();
            this.cbIncomeType = new Wisej.Web.ComboBox();
            this.label3 = new Wisej.Web.Label();
            this.txtMinistry = new Wisej.Web.TextBox();
            this.label2 = new Wisej.Web.Label();
            this.txtMemberName = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.panel7 = new Wisej.Web.Panel();
            this.cbPaymentMonth = new Wisej.Web.ComboBox();
            this.cbPaymentYear = new Wisej.Web.ComboBox();
            this.label8 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.txtTransAccount = new Wisej.Web.TextBox();
            this.label5 = new Wisej.Web.Label();
            this.txtAccountNo = new Wisej.Web.TextBox();
            this.label4 = new Wisej.Web.Label();
            this.panel4 = new Wisej.Web.Panel();
            this.rdBankTransfer = new Wisej.Web.RadioButton();
            this.rdCash = new Wisej.Web.RadioButton();
            this.rdCheque = new Wisej.Web.RadioButton();
            this.panel2 = new Wisej.Web.Panel();
            this.rbTitheNumber = new Wisej.Web.RadioButton();
            this.rbMemberName = new Wisej.Web.RadioButton();
            this.btnGetTithe = new Wisej.Web.Button();
            this.txtGetTithe = new Wisej.Web.TextBox();
            this.panel5 = new Wisej.Web.Panel();
            this.toolBar1 = new Wisej.Web.ToolBar();
            this.btnPostTransaction = new Wisej.Web.ToolBarButton();
            this.btnCancelTransaction = new Wisej.Web.ToolBarButton();
            this.btnClearScreen = new Wisej.Web.ToolBarButton();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Location = new System.Drawing.Point(6, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1003, 427);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.cbService);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.panel8);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel3.HeaderForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(487, 8);
            this.panel3.Name = "panel3";
            this.panel3.ShowHeader = true;
            this.panel3.Size = new System.Drawing.Size(492, 573);
            this.panel3.TabIndex = 5;
            this.panel3.TabStop = true;
            this.panel3.Text = "No GL Receipt";
            // 
            // cbService
            // 
            this.cbService.Items.AddRange(new object[] {
            "Sunday - First Service ",
            "Sunday - Second Service",
            "Sunday - Third Service",
            "Perez Hour",
            "All-Night Service",
            "Crusade",
            "Tuesday Breakthrough Service",
            "Extended Prayer Meeting"});
            this.cbService.Location = new System.Drawing.Point(9, 511);
            this.cbService.Name = "cbService";
            this.cbService.Size = new System.Drawing.Size(469, 22);
            this.cbService.TabIndex = 16;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 490);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 15);
            this.label11.TabIndex = 15;
            this.label11.Text = "Service";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel9.Controls.Add(this.txtTitheRefNo);
            this.panel9.Controls.Add(this.label10);
            this.panel9.Controls.Add(this.txtTitheNo);
            this.panel9.Controls.Add(this.label9);
            this.panel9.Controls.Add(this.label6);
            this.panel9.Controls.Add(this.dtpActualDepositDate);
            this.panel9.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel9.HeaderForeColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(9, 404);
            this.panel9.Name = "panel9";
            this.panel9.ShowHeader = true;
            this.panel9.Size = new System.Drawing.Size(469, 83);
            this.panel9.TabIndex = 3;
            this.panel9.TabStop = true;
            this.panel9.Text = "Tithe";
            // 
            // txtTitheRefNo
            // 
            this.txtTitheRefNo.Location = new System.Drawing.Point(343, 24);
            this.txtTitheRefNo.Name = "txtTitheRefNo";
            this.txtTitheRefNo.Size = new System.Drawing.Size(106, 22);
            this.txtTitheRefNo.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(340, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 15);
            this.label10.TabIndex = 13;
            this.label10.Text = "Tithe RefNo.";
            // 
            // txtTitheNo
            // 
            this.txtTitheNo.Location = new System.Drawing.Point(228, 24);
            this.txtTitheNo.Name = "txtTitheNo";
            this.txtTitheNo.Size = new System.Drawing.Size(91, 22);
            this.txtTitheNo.TabIndex = 12;
            this.txtTitheNo.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(228, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 15);
            this.label9.TabIndex = 11;
            this.label9.Text = "Tithe No.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Actual Deposit Date";
            // 
            // dtpActualDepositDate
            // 
            this.dtpActualDepositDate.Checked = false;
            this.dtpActualDepositDate.Location = new System.Drawing.Point(7, 24);
            this.dtpActualDepositDate.Name = "dtpActualDepositDate";
            this.dtpActualDepositDate.Size = new System.Drawing.Size(200, 22);
            this.dtpActualDepositDate.TabIndex = 9;
            this.dtpActualDepositDate.Value = new System.DateTime(2020, 8, 13, 5, 52, 32, 512);
            // 
            // panel8
            // 
            this.panel8.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel8.Controls.Add(this.cbIncomeType);
            this.panel8.Controls.Add(this.label3);
            this.panel8.Controls.Add(this.txtMinistry);
            this.panel8.Controls.Add(this.label2);
            this.panel8.Controls.Add(this.txtMemberName);
            this.panel8.Controls.Add(this.label1);
            this.panel8.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel8.HeaderForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(11, 48);
            this.panel8.Name = "panel8";
            this.panel8.ShowHeader = true;
            this.panel8.Size = new System.Drawing.Size(469, 181);
            this.panel8.TabIndex = 2;
            this.panel8.TabStop = true;
            this.panel8.Text = "Personal Detail";
            // 
            // cbIncomeType
            // 
            this.cbIncomeType.Location = new System.Drawing.Point(12, 119);
            this.cbIncomeType.Name = "cbIncomeType";
            this.cbIncomeType.Size = new System.Drawing.Size(437, 22);
            this.cbIncomeType.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Income Type";
            // 
            // txtMinistry
            // 
            this.txtMinistry.Location = new System.Drawing.Point(12, 71);
            this.txtMinistry.Name = "txtMinistry";
            this.txtMinistry.Size = new System.Drawing.Size(437, 22);
            this.txtMinistry.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Ministry";
            // 
            // txtMemberName
            // 
            this.txtMemberName.Location = new System.Drawing.Point(12, 22);
            this.txtMemberName.Name = "txtMemberName";
            this.txtMemberName.Size = new System.Drawing.Size(437, 22);
            this.txtMemberName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Member Name";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel7.Controls.Add(this.cbPaymentMonth);
            this.panel7.Controls.Add(this.cbPaymentYear);
            this.panel7.Controls.Add(this.label8);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Controls.Add(this.txtTransAccount);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.txtAccountNo);
            this.panel7.Controls.Add(this.label4);
            this.panel7.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel7.HeaderForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(10, 229);
            this.panel7.Name = "panel7";
            this.panel7.ShowHeader = true;
            this.panel7.Size = new System.Drawing.Size(469, 174);
            this.panel7.TabIndex = 1;
            this.panel7.TabStop = true;
            this.panel7.Text = "Acount Detail";
            // 
            // cbPaymentMonth
            // 
            this.cbPaymentMonth.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbPaymentMonth.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.cbPaymentMonth.Location = new System.Drawing.Point(12, 115);
            this.cbPaymentMonth.Name = "cbPaymentMonth";
            this.cbPaymentMonth.Size = new System.Drawing.Size(195, 22);
            this.cbPaymentMonth.TabIndex = 15;
            // 
            // cbPaymentYear
            // 
            this.cbPaymentYear.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbPaymentYear.Items.AddRange(new object[] {
            "2019",
            "2020"});
            this.cbPaymentYear.Location = new System.Drawing.Point(222, 115);
            this.cbPaymentYear.Name = "cbPaymentYear";
            this.cbPaymentYear.Size = new System.Drawing.Size(195, 22);
            this.cbPaymentYear.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(222, 94);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 15);
            this.label8.TabIndex = 13;
            this.label8.Text = "Payment Year";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 15);
            this.label7.TabIndex = 12;
            this.label7.Text = "Payment Month";
            // 
            // txtTransAccount
            // 
            this.txtTransAccount.Location = new System.Drawing.Point(12, 66);
            this.txtTransAccount.Name = "txtTransAccount";
            this.txtTransAccount.Size = new System.Drawing.Size(437, 22);
            this.txtTransAccount.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Trans. Account ";
            // 
            // txtAccountNo
            // 
            this.txtAccountNo.Location = new System.Drawing.Point(12, 17);
            this.txtAccountNo.Name = "txtAccountNo";
            this.txtAccountNo.Size = new System.Drawing.Size(437, 22);
            this.txtAccountNo.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 15);
            this.label4.TabIndex = 5;
            this.label4.Text = "Account No.";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromName("@tabHighlight");
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.rdBankTransfer);
            this.panel4.Controls.Add(this.rdCash);
            this.panel4.Controls.Add(this.rdCheque);
            this.panel4.ForeColor = System.Drawing.Color.FromArgb(7, 5, 58);
            this.panel4.Location = new System.Drawing.Point(10, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(469, 44);
            this.panel4.TabIndex = 0;
            this.panel4.TabStop = true;
            // 
            // rdBankTransfer
            // 
            this.rdBankTransfer.Location = new System.Drawing.Point(310, 11);
            this.rdBankTransfer.Name = "rdBankTransfer";
            this.rdBankTransfer.Size = new System.Drawing.Size(141, 22);
            this.rdBankTransfer.TabIndex = 1;
            this.rdBankTransfer.TabStop = true;
            this.rdBankTransfer.Text = "BANK TRANSFER";
            // 
            // rdCash
            // 
            this.rdCash.Location = new System.Drawing.Point(13, 11);
            this.rdCash.Name = "rdCash";
            this.rdCash.Size = new System.Drawing.Size(68, 22);
            this.rdCash.TabIndex = 6;
            this.rdCash.TabStop = true;
            this.rdCash.Text = "CASH";
            this.rdCash.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rdCheque
            // 
            this.rdCheque.Location = new System.Drawing.Point(164, 11);
            this.rdCheque.Name = "rdCheque";
            this.rdCheque.Size = new System.Drawing.Size(87, 22);
            this.rdCheque.TabIndex = 0;
            this.rdCheque.TabStop = true;
            this.rdCheque.Text = "CHEQUE";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.rbTitheNumber);
            this.panel2.Controls.Add(this.rbMemberName);
            this.panel2.Controls.Add(this.btnGetTithe);
            this.panel2.Controls.Add(this.txtGetTithe);
            this.panel2.Location = new System.Drawing.Point(6, 8);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(471, 89);
            this.panel2.TabIndex = 4;
            this.panel2.TabStop = true;
            // 
            // rbTitheNumber
            // 
            this.rbTitheNumber.Location = new System.Drawing.Point(180, 3);
            this.rbTitheNumber.Name = "rbTitheNumber";
            this.rbTitheNumber.Size = new System.Drawing.Size(110, 22);
            this.rbTitheNumber.TabIndex = 0;
            this.rbTitheNumber.TabStop = true;
            this.rbTitheNumber.Text = "Tithe Number";
            // 
            // rbMemberName
            // 
            this.rbMemberName.Location = new System.Drawing.Point(26, 2);
            this.rbMemberName.Name = "rbMemberName";
            this.rbMemberName.Size = new System.Drawing.Size(117, 22);
            this.rbMemberName.TabIndex = 5;
            this.rbMemberName.TabStop = true;
            this.rbMemberName.Text = "Member Name";
            // 
            // btnGetTithe
            // 
            this.btnGetTithe.Location = new System.Drawing.Point(333, 28);
            this.btnGetTithe.Name = "btnGetTithe";
            this.btnGetTithe.Size = new System.Drawing.Size(105, 27);
            this.btnGetTithe.TabIndex = 4;
            this.btnGetTithe.Text = "Get Tithe";
            // 
            // txtGetTithe
            // 
            this.txtGetTithe.Location = new System.Drawing.Point(17, 31);
            this.txtGetTithe.Name = "txtGetTithe";
            this.txtGetTithe.Size = new System.Drawing.Size(273, 22);
            this.txtGetTithe.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel5.HeaderForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(7, 98);
            this.panel5.Name = "panel5";
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(471, 483);
            this.panel5.TabIndex = 3;
            this.panel5.TabStop = true;
            this.panel5.Text = "Member Search Result";
            // 
            // toolBar1
            // 
            this.toolBar1.AutoSize = false;
            this.toolBar1.BackColor = System.Drawing.Color.FromName("@table-row-background-selected");
            this.toolBar1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.toolBar1.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnPostTransaction,
            this.btnCancelTransaction,
            this.btnClearScreen});
            this.toolBar1.Dock = Wisej.Web.DockStyle.None;
            this.toolBar1.ForeColor = System.Drawing.Color.Black;
            this.toolBar1.Location = new System.Drawing.Point(3, 469);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(1006, 60);
            this.toolBar1.TabIndex = 1;
            this.toolBar1.TabStop = false;
            this.toolBar1.ButtonClick += new Wisej.Web.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
            // 
            // btnPostTransaction
            // 
            this.btnPostTransaction.ImageSource = "icon-new";
            this.btnPostTransaction.Name = "btnPostTransaction";
            this.btnPostTransaction.Text = "Post Transaction";
            this.btnPostTransaction.Click += new System.EventHandler(this.toolBarButton1_Click);
            // 
            // btnCancelTransaction
            // 
            this.btnCancelTransaction.ImageSource = "tab-close";
            this.btnCancelTransaction.Name = "btnCancelTransaction";
            this.btnCancelTransaction.Text = "Cancel Transaction";
            this.btnCancelTransaction.Click += new System.EventHandler(this.btnCancelTransaction_Click);
            // 
            // btnClearScreen
            // 
            this.btnClearScreen.ImageSource = "icon-close";
            this.btnClearScreen.Name = "btnClearScreen";
            this.btnClearScreen.Text = "Clear Screen";
            this.btnClearScreen.Click += new System.EventHandler(this.btnClearScreen_Click);
            // 
            // ucPro
            // 
            this.Controls.Add(this.toolBar1);
            this.Controls.Add(this.panel1);
            this.Name = "ucPro";
            this.ScrollBars = Wisej.Web.ScrollBars.None;
            this.Size = new System.Drawing.Size(1047, 551);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel9;
        private Wisej.Web.TextBox txtTitheRefNo;
        private Wisej.Web.Label label10;
        private Wisej.Web.TextBox txtTitheNo;
        private Wisej.Web.Label label9;
        private Wisej.Web.Label label6;
        private Wisej.Web.DateTimePicker dtpActualDepositDate;
        private Wisej.Web.Panel panel8;
        private Wisej.Web.ComboBox cbIncomeType;
        private Wisej.Web.Label label3;
        private Wisej.Web.TextBox txtMinistry;
        private Wisej.Web.Label label2;
        private Wisej.Web.TextBox txtMemberName;
        private Wisej.Web.Label label1;
        private Wisej.Web.Panel panel7;
        private Wisej.Web.ComboBox cbPaymentMonth;
        private Wisej.Web.ComboBox cbPaymentYear;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label7;
        private Wisej.Web.TextBox txtTransAccount;
        private Wisej.Web.Label label5;
        private Wisej.Web.TextBox txtAccountNo;
        private Wisej.Web.Label label4;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.ComboBox cbService;
        private Wisej.Web.Label label11;
        private Wisej.Web.Button btnGetTithe;
        private Wisej.Web.TextBox txtGetTithe;
        private Wisej.Web.ToolBar toolBar1;
        private Wisej.Web.ToolBarButton btnPostTransaction;
        private Wisej.Web.ToolBarButton btnCancelTransaction;
        private Wisej.Web.ToolBarButton btnClearScreen;
        private Wisej.Web.RadioButton rbTitheNumber;
        private Wisej.Web.RadioButton rbMemberName;
        private Wisej.Web.RadioButton rdCash;
        private Wisej.Web.RadioButton rdBankTransfer;
        private Wisej.Web.RadioButton rdCheque;
    }
}
