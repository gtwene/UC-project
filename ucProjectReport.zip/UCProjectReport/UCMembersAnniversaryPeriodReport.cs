﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucMembersAnniversaryPeriodReport : Wisej.Web.UserControl
    {
        public ucMembersAnniversaryPeriodReport()
        {
            InitializeComponent();
        }
    }
}
