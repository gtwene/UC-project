﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucMembersInfoMembersReport : Wisej.Web.UserControl
    {
        public ucMembersInfoMembersReport()
        {
            InitializeComponent();
        }
    }
}
