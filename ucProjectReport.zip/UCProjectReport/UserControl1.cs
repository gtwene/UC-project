﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UserControl1 : Wisej.Web.UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }
    }
}
