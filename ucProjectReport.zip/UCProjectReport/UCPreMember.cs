﻿using System;
using System.Runtime.CompilerServices;
using Wisej.Web;

namespace UCProject
{
    public partial class ucPreMember : Wisej.Web.UserControl
    {
        public ucPreMember()
        {
            InitializeComponent();
        }

        private void UCPreMember_Load(object sender, EventArgs e)
        {

        }

        private void toolBar1_ButtonClick(object sender, ToolBarButtonClickEventArgs e)
        {

        }

        private void btnSavePreMember_Click(object sender, EventArgs e)
        {
            try
            {
                if (Validate_Controls() == false)
                {
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Create Pre-member ?", GlobalValueCore.ApplicationName, MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {

                    if (CreatePreMember())
                    {
      
                        GlobalValueCore.InformationMessage("Pre member Created Successfully");
                        //CLEAR_TEXT();
                                            }
                }
                else if (dialogResult == DialogResult.No)
                {
                    GlobalValueCore.InformationMessage("Cancelled by User");
                }
                //MessageBox.Show(""+branch.checkBranchName(txtBranchName.Text.ToString()));

            }
            catch (Exception ex)
            {
                GlobalValueCore.ExceptionMessage(ex.Message);
            }

        }



        private bool CreatePreMember()
        {
            throw new NotImplementedException();
        }

        private bool Validate_Controls()
        {
            if (dtpattendance.Value > DateTime.Today.Date)
            {
                MessageBox.Show("Cannto Select Futre Date");
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbChurchAttendance.Text, "Select Church Attended. Process Aboretd !"))
            {
                cbChurchAttendance.Select();
                return false;
            }



            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbServiceAttendance, cbServiceAttendance.Text, "Select Church Attended. Process Aboretd !"))
            {
                cbServiceAttendance.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbMemberType, cbMemberType.Text, "Select Memebr Type. Process Aboretd !"))
            {
                cbChurchAttendance.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtSurname.Text, "Enter Surname."))
            {
                txtSurname.Select();
                return false;
            }
            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtOthernames.Text, "Enter OtherNames."))
            {
                txtOthernames.Select();
                return false;
            }
            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbGender, cbGender.Text, "Please Select a Gender"))
            {
                cbGender.Select();
                return false;

            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(tbEmail.Text, "Please Enter Your Email Address"))
            {
                tbEmail.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtMobileNumber.Text, "Please Enter Your Phone Number"))
            {
                txtMobileNumber.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtTelephoneNumber.Text, "Please Enter Your Telephone Number"))
            {
                txtTelephoneNumber.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtResidentialAddress.Text, "Please Where do you Stay ?"))
            {
                txtResidentialAddress.Select();
                    return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(cbSurburbArea, cbSurburbArea.Text, "Please The Surburb ?"))
            {
                cbSurburbArea.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(cbEmploymentStatus, cbEmploymentStatus.Text, "Please What's Your Employment Status ?"))
            {
                cbEmploymentStatus.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtNameOfEmployer.Text, "Please Enter Your Name"))
            {
                txtNameOfEmployer.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtDesignation.Text, "Please Enter Designation"))
            {
                txtDesignation.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtBusinessAddress.Text, "Please Enter Your Business Address"))
            {
                txtBusinessAddress.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtNameOfSchool.Text, "Please Enter The Name Of Your School"))
            {
                txtNameOfSchool.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(cbAcademic, cbAcademic.Text, "Please Select The Academic Level"))
            {
                cbAcademic.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtlevelform.Text, "Please Enter Your Level or Form"))
            {
                txtlevelform.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtProgramOfStudy.Text, "Please Enter Program Of Study"))
            {
                txtProgramOfStudy.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(cbResidentOnCampus, cbResidentOnCampus.Text, "Please Enter your Residence"))
            {
                cbResidentOnCampus.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtHallOfAffiliation.Text, " Please Enter Your Hall Of Affiliation"))
            {
                txtHallOfAffiliation.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtRoomNumber.Text, "Please Enter Your Room Number"))
            {
                txtRoomNumber.Select();
                return false;
            }

            //if (cbEmploymentStatus.Text == "Student")
            //{
            //    pResidentialinfo.Show();

            //}else
            //{
            //    pStudentResidentialInfo_PanelCollapsed()
            //}
            

            return true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (Validate_Controls() == false) return;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            CLEAR_TEXT();
        }

        private void CLEAR_TEXT()
        {
            txtSurname.Text = txtOthernames.Text = txtProgramOfStudy.Text = txtNameOfSchool.Text = "";
            cbChurchAttendance.SelectedIndex = cbServiceAttendance.SelectedIndex = -1;
        }

        private void cbChurchAttendance_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pStudentResidentialInfo_PanelCollapsed(object sender, EventArgs e)
        {

        }

        private void txtSurname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtHallOfAffiliation_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
