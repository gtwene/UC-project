﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucChurchAttendanceReport : Wisej.Web.UserControl
    {
        public ucChurchAttendanceReport()
        {
            InitializeComponent();
        }
    }
}
