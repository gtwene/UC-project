﻿namespace UCProject
{
    partial class ucBulkSMS
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbSendByMinistry = new Wisej.Web.RadioButton();
            this.rbSendToIndividual = new Wisej.Web.RadioButton();
            this.rbSendByDepartment = new Wisej.Web.RadioButton();
            this.panel1 = new Wisej.Web.Panel();
            this.cbDepartment = new Wisej.Web.ComboBox();
            this.cbChurch = new Wisej.Web.ComboBox();
            this.label11 = new Wisej.Web.Label();
            this.label10 = new Wisej.Web.Label();
            this.panel3 = new Wisej.Web.Panel();
            this.panelSearchResults = new Wisej.Web.Panel();
            this.label8 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.label5 = new Wisej.Web.Label();
            this.btnClearList = new Wisej.Web.Button();
            this.btnAddtoList = new Wisej.Web.Button();
            this.txtChurch = new Wisej.Web.TextBox();
            this.txtFullName = new Wisej.Web.TextBox();
            this.txtMembershipNo = new Wisej.Web.TextBox();
            this.txtMobileNo = new Wisej.Web.TextBox();
            this.panel4 = new Wisej.Web.Panel();
            this.label4 = new Wisej.Web.Label();
            this.labelMembers = new Wisej.Web.Label();
            this.labelPages = new Wisej.Web.Label();
            this.labelNoOfCharacters = new Wisej.Web.Label();
            this.txtMessage = new Wisej.Web.TextBox();
            this.ckConfirmMessage = new Wisej.Web.CheckBox();
            this.btnCancel = new Wisej.Web.Button();
            this.btnSendSMSToMembers = new Wisej.Web.Button();
            this.label9 = new Wisej.Web.Label();
            this.panel6 = new Wisej.Web.Panel();
            this.panelIndividualMemberList = new Wisej.Web.Panel();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbSendByMinistry
            // 
            this.rbSendByMinistry.ForeColor = System.Drawing.Color.Black;
            this.rbSendByMinistry.Location = new System.Drawing.Point(9, 2);
            this.rbSendByMinistry.Name = "rbSendByMinistry";
            this.rbSendByMinistry.Size = new System.Drawing.Size(129, 22);
            this.rbSendByMinistry.TabIndex = 1;
            this.rbSendByMinistry.TabStop = true;
            this.rbSendByMinistry.Text = "Send By Ministry";
            // 
            // rbSendToIndividual
            // 
            this.rbSendToIndividual.ForeColor = System.Drawing.Color.Black;
            this.rbSendToIndividual.Location = new System.Drawing.Point(334, 2);
            this.rbSendToIndividual.Name = "rbSendToIndividual";
            this.rbSendToIndividual.Size = new System.Drawing.Size(190, 22);
            this.rbSendToIndividual.TabIndex = 2;
            this.rbSendToIndividual.TabStop = true;
            this.rbSendToIndividual.Text = "Send To Individual Member";
            // 
            // rbSendByDepartment
            // 
            this.rbSendByDepartment.ForeColor = System.Drawing.Color.Black;
            this.rbSendByDepartment.Location = new System.Drawing.Point(156, 2);
            this.rbSendByDepartment.Name = "rbSendByDepartment";
            this.rbSendByDepartment.Size = new System.Drawing.Size(152, 22);
            this.rbSendByDepartment.TabIndex = 3;
            this.rbSendByDepartment.TabStop = true;
            this.rbSendByDepartment.Text = "Send By Department";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.cbDepartment);
            this.panel1.Controls.Add(this.cbChurch);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel1.HeaderForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(14, 58);
            this.panel1.Name = "panel1";
            this.panel1.ShowCloseButton = false;
            this.panel1.ShowHeader = true;
            this.panel1.Size = new System.Drawing.Size(397, 117);
            this.panel1.TabIndex = 4;
            this.panel1.TabStop = true;
            this.panel1.Text = "Ministry/Department";
            // 
            // cbDepartment
            // 
            this.cbDepartment.LabelText = "";
            this.cbDepartment.Location = new System.Drawing.Point(141, 51);
            this.cbDepartment.Name = "cbDepartment";
            this.cbDepartment.Size = new System.Drawing.Size(240, 22);
            this.cbDepartment.TabIndex = 12;
            // 
            // cbChurch
            // 
            this.cbChurch.LabelText = "";
            this.cbChurch.Location = new System.Drawing.Point(141, 9);
            this.cbChurch.Name = "cbChurch";
            this.cbChurch.Size = new System.Drawing.Size(240, 22);
            this.cbChurch.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(16, 55);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 15);
            this.label11.TabIndex = 10;
            this.label11.Text = "Department";
            // 
            // label10
            // 
            this.label10.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(16, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "Ministry/Church";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.panelSearchResults);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.btnClearList);
            this.panel3.Controls.Add(this.btnAddtoList);
            this.panel3.Controls.Add(this.txtChurch);
            this.panel3.Controls.Add(this.txtFullName);
            this.panel3.Controls.Add(this.txtMembershipNo);
            this.panel3.Controls.Add(this.txtMobileNo);
            this.panel3.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel3.HeaderForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(14, 177);
            this.panel3.Name = "panel3";
            this.panel3.ShowCloseButton = false;
            this.panel3.ShowHeader = true;
            this.panel3.Size = new System.Drawing.Size(397, 381);
            this.panel3.TabIndex = 5;
            this.panel3.TabStop = true;
            this.panel3.Text = "Search For Individual Member";
            // 
            // panelSearchResults
            // 
            this.panelSearchResults.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panelSearchResults.Location = new System.Drawing.Point(16, 15);
            this.panelSearchResults.Name = "panelSearchResults";
            this.panelSearchResults.ShowCloseButton = false;
            this.panelSearchResults.ShowHeader = true;
            this.panelSearchResults.Size = new System.Drawing.Size(365, 165);
            this.panelSearchResults.TabIndex = 12;
            this.panelSearchResults.TabStop = true;
            this.panelSearchResults.Text = "Search Results";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(25, 292);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 15);
            this.label8.TabIndex = 11;
            this.label8.Text = "Ministry/Church";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(25, 264);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Mobile No.";
            // 
            // label6
            // 
            this.label6.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(25, 236);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "Full Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(25, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Membership No.";
            // 
            // btnClearList
            // 
            this.btnClearList.BackColor = System.Drawing.Color.LightGray;
            this.btnClearList.ForeColor = System.Drawing.Color.Black;
            this.btnClearList.Location = new System.Drawing.Point(281, 320);
            this.btnClearList.Name = "btnClearList";
            this.btnClearList.Size = new System.Drawing.Size(100, 27);
            this.btnClearList.TabIndex = 5;
            this.btnClearList.Text = "Clear List";
            this.btnClearList.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnAddtoList
            // 
            this.btnAddtoList.BackColor = System.Drawing.Color.LightGray;
            this.btnAddtoList.ForeColor = System.Drawing.Color.Black;
            this.btnAddtoList.Location = new System.Drawing.Point(141, 320);
            this.btnAddtoList.Name = "btnAddtoList";
            this.btnAddtoList.Size = new System.Drawing.Size(100, 27);
            this.btnAddtoList.TabIndex = 4;
            this.btnAddtoList.Text = "Add To List";
            this.btnAddtoList.Click += new System.EventHandler(this.btnAddtoList_Click);
            // 
            // txtChurch
            // 
            this.txtChurch.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.txtChurch.LabelText = "";
            this.txtChurch.Location = new System.Drawing.Point(141, 292);
            this.txtChurch.Name = "txtChurch";
            this.txtChurch.Size = new System.Drawing.Size(240, 22);
            this.txtChurch.TabIndex = 3;
            // 
            // txtFullName
            // 
            this.txtFullName.LabelText = "";
            this.txtFullName.Location = new System.Drawing.Point(141, 236);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(240, 22);
            this.txtFullName.TabIndex = 2;
            // 
            // txtMembershipNo
            // 
            this.txtMembershipNo.LabelText = "";
            this.txtMembershipNo.Location = new System.Drawing.Point(141, 208);
            this.txtMembershipNo.Name = "txtMembershipNo";
            this.txtMembershipNo.Size = new System.Drawing.Size(240, 22);
            this.txtMembershipNo.TabIndex = 1;
            // 
            // txtMobileNo
            // 
            this.txtMobileNo.LabelText = "";
            this.txtMobileNo.Location = new System.Drawing.Point(141, 264);
            this.txtMobileNo.Name = "txtMobileNo";
            this.txtMobileNo.Size = new System.Drawing.Size(240, 22);
            this.txtMobileNo.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.labelMembers);
            this.panel4.Controls.Add(this.labelPages);
            this.panel4.Controls.Add(this.labelNoOfCharacters);
            this.panel4.Controls.Add(this.txtMessage);
            this.panel4.Controls.Add(this.ckConfirmMessage);
            this.panel4.Controls.Add(this.btnCancel);
            this.panel4.Controls.Add(this.btnSendSMSToMembers);
            this.panel4.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel4.HeaderForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(417, 271);
            this.panel4.Name = "panel4";
            this.panel4.ShowCloseButton = false;
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(438, 287);
            this.panel4.TabIndex = 6;
            this.panel4.TabStop = true;
            this.panel4.Text = "Message";
            this.panel4.PanelCollapsed += new System.EventHandler(this.panel4_PanelCollapsed);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(25, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Message";
            // 
            // labelMembers
            // 
            this.labelMembers.AutoSize = true;
            this.labelMembers.ForeColor = System.Drawing.Color.Black;
            this.labelMembers.Location = new System.Drawing.Point(318, 142);
            this.labelMembers.Name = "labelMembers";
            this.labelMembers.Size = new System.Drawing.Size(84, 15);
            this.labelMembers.TabIndex = 6;
            this.labelMembers.Text = "|  Member(s) :";
            // 
            // labelPages
            // 
            this.labelPages.AutoSize = true;
            this.labelPages.ForeColor = System.Drawing.Color.Black;
            this.labelPages.Location = new System.Drawing.Point(202, 142);
            this.labelPages.Name = "labelPages";
            this.labelPages.Size = new System.Drawing.Size(58, 15);
            this.labelPages.TabIndex = 5;
            this.labelPages.Text = "|  Pages :";
            // 
            // labelNoOfCharacters
            // 
            this.labelNoOfCharacters.AutoSize = true;
            this.labelNoOfCharacters.ForeColor = System.Drawing.Color.Black;
            this.labelNoOfCharacters.Location = new System.Drawing.Point(26, 142);
            this.labelNoOfCharacters.Name = "labelNoOfCharacters";
            this.labelNoOfCharacters.Size = new System.Drawing.Size(115, 15);
            this.labelNoOfCharacters.TabIndex = 4;
            this.labelNoOfCharacters.Text = "No. Of Characters :";
            // 
            // txtMessage
            // 
            this.txtMessage.LabelText = "";
            this.txtMessage.Location = new System.Drawing.Point(103, 19);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(300, 111);
            this.txtMessage.TabIndex = 3;
            // 
            // ckConfirmMessage
            // 
            this.ckConfirmMessage.Location = new System.Drawing.Point(26, 195);
            this.ckConfirmMessage.Name = "ckConfirmMessage";
            this.ckConfirmMessage.Size = new System.Drawing.Size(279, 22);
            this.ckConfirmMessage.TabIndex = 2;
            this.ckConfirmMessage.Text = "Confirm message and Message Recipients";
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(266, 226);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(137, 27);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnSendSMSToMembers
            // 
            this.btnSendSMSToMembers.BackColor = System.Drawing.Color.LightGray;
            this.btnSendSMSToMembers.ForeColor = System.Drawing.Color.Black;
            this.btnSendSMSToMembers.Location = new System.Drawing.Point(25, 226);
            this.btnSendSMSToMembers.Name = "btnSendSMSToMembers";
            this.btnSendSMSToMembers.Size = new System.Drawing.Size(177, 27);
            this.btnSendSMSToMembers.TabIndex = 0;
            this.btnSendSMSToMembers.Text = "Send SMS To Member(s)";
            this.btnSendSMSToMembers.Click += new System.EventHandler(this.btnSendSMSToMembers_Click);
            // 
            // label9
            // 
            this.label9.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(366, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 15);
            this.label9.TabIndex = 13;
            this.label9.Text = "BULK MESSAGES";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightBlue;
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.rbSendByDepartment);
            this.panel6.Controls.Add(this.rbSendToIndividual);
            this.panel6.Controls.Add(this.rbSendByMinistry);
            this.panel6.Location = new System.Drawing.Point(14, 27);
            this.panel6.Name = "panel6";
            this.panel6.ShowCloseButton = false;
            this.panel6.Size = new System.Drawing.Size(841, 29);
            this.panel6.TabIndex = 14;
            this.panel6.TabStop = true;
            // 
            // panelIndividualMemberList
            // 
            this.panelIndividualMemberList.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panelIndividualMemberList.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panelIndividualMemberList.HeaderForeColor = System.Drawing.Color.Black;
            this.panelIndividualMemberList.Location = new System.Drawing.Point(417, 58);
            this.panelIndividualMemberList.Name = "panelIndividualMemberList";
            this.panelIndividualMemberList.ShowHeader = true;
            this.panelIndividualMemberList.Size = new System.Drawing.Size(438, 212);
            this.panelIndividualMemberList.TabIndex = 5;
            this.panelIndividualMemberList.TabStop = true;
            this.panelIndividualMemberList.Text = "Individual Member List";
            // 
            // ucBulkSMS
            // 
            this.AutoScroll = true;
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panelIndividualMemberList);
            this.Controls.Add(this.panel1);
            this.Name = "ucBulkSMS";
            this.Size = new System.Drawing.Size(807, 446);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Wisej.Web.RadioButton rbSendByMinistry;
        private Wisej.Web.RadioButton rbSendToIndividual;
        private Wisej.Web.RadioButton rbSendByDepartment;
        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.TextBox txtMessage;
        private Wisej.Web.CheckBox ckConfirmMessage;
        private Wisej.Web.Button btnCancel;
        private Wisej.Web.Button btnSendSMSToMembers;
        private Wisej.Web.Panel panelSearchResults;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label5;
        private Wisej.Web.Button btnClearList;
        private Wisej.Web.Button btnAddtoList;
        private Wisej.Web.TextBox txtChurch;
        private Wisej.Web.TextBox txtFullName;
        private Wisej.Web.TextBox txtMembershipNo;
        private Wisej.Web.TextBox txtMobileNo;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label labelMembers;
        private Wisej.Web.Label labelPages;
        private Wisej.Web.Label labelNoOfCharacters;
        private Wisej.Web.ComboBox cbDepartment;
        private Wisej.Web.ComboBox cbChurch;
        private Wisej.Web.Label label11;
        private Wisej.Web.Label label10;
        private Wisej.Web.Label label9;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.Panel panelIndividualMemberList;
    }
}
