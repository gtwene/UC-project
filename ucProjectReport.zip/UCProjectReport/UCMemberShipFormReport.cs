﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucMemberShipFormReport : Wisej.Web.UserControl
    {
        public ucMemberShipFormReport()
        {
            InitializeComponent();
        }
    }
}
