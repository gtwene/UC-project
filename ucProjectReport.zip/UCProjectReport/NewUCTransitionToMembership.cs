﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class NewUCTransitionToMembership : Wisej.Web.UserControl
    {
        public NewUCTransitionToMembership()
        {
            InitializeComponent();
        }

        
        private void btnPreMemberToMember_Click(object sender, EventArgs e)
        {
          
        }
    }
}
