﻿namespace UCProject
{
    partial class ucPrememberManagerChuchAttendance
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel5 = new Wisej.Web.Panel();
            this.panel4 = new Wisej.Web.Panel();
            this.dtpDate = new Wisej.Web.DateTimePicker();
            this.cbChurchAttended = new Wisej.Web.ComboBox();
            this.txtChurchAttended = new Wisej.Web.TextBox();
            this.cbService = new Wisej.Web.ComboBox();
            this.txtService = new Wisej.Web.TextBox();
            this.txtAttendance = new Wisej.Web.TextBox();
            this.toolBar1 = new Wisej.Web.ToolBar();
            this.btnAddAttendance = new Wisej.Web.ToolBarButton();
            this.btnCancel = new Wisej.Web.ToolBarButton();
            this.label7 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.label5 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.panel3 = new Wisej.Web.Panel();
            this.btnViewChurchAttendance = new Wisej.Web.Button();
            this.panel7 = new Wisej.Web.Panel();
            this.cbView = new Wisej.Web.ComboBox();
            this.rbChurchMinistry = new Wisej.Web.RadioButton();
            this.rbServiceType = new Wisej.Web.RadioButton();
            this.rbGlobal = new Wisej.Web.RadioButton();
            this.panel6 = new Wisej.Web.Panel();
            this.dtpDateTo = new Wisej.Web.DateTimePicker();
            this.dtpDateFrom = new Wisej.Web.DateTimePicker();
            this.label3 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.panel2 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(15, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(868, 437);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel5.HeaderForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(13, 132);
            this.panel5.Name = "panel5";
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(131, 288);
            this.panel5.TabIndex = 3;
            this.panel5.TabStop = true;
            this.panel5.Text = "Attendance";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.dtpDate);
            this.panel4.Controls.Add(this.cbChurchAttended);
            this.panel4.Controls.Add(this.txtChurchAttended);
            this.panel4.Controls.Add(this.cbService);
            this.panel4.Controls.Add(this.txtService);
            this.panel4.Controls.Add(this.txtAttendance);
            this.panel4.Controls.Add(this.toolBar1);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label4);
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel4.HeaderForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(198, 132);
            this.panel4.Name = "panel4";
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(361, 289);
            this.panel4.TabIndex = 2;
            this.panel4.TabStop = true;
            this.panel4.Text = "Create / Edit Attendance";
            // 
            // dtpDate
            // 
            this.dtpDate.Checked = false;
            this.dtpDate.Location = new System.Drawing.Point(148, 25);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(200, 22);
            this.dtpDate.TabIndex = 4;
            this.dtpDate.Value = new System.DateTime(2020, 10, 13, 17, 41, 34, 950);
            // 
            // cbChurchAttended
            // 
            this.cbChurchAttended.Location = new System.Drawing.Point(148, 61);
            this.cbChurchAttended.Name = "cbChurchAttended";
            this.cbChurchAttended.Size = new System.Drawing.Size(200, 22);
            this.cbChurchAttended.TabIndex = 13;
            // 
            // txtChurchAttended
            // 
            this.txtChurchAttended.Location = new System.Drawing.Point(148, 85);
            this.txtChurchAttended.Name = "txtChurchAttended";
            this.txtChurchAttended.Size = new System.Drawing.Size(200, 22);
            this.txtChurchAttended.TabIndex = 12;
            // 
            // cbService
            // 
            this.cbService.Location = new System.Drawing.Point(148, 116);
            this.cbService.Name = "cbService";
            this.cbService.Size = new System.Drawing.Size(200, 22);
            this.cbService.TabIndex = 11;
            // 
            // txtService
            // 
            this.txtService.Location = new System.Drawing.Point(148, 140);
            this.txtService.Name = "txtService";
            this.txtService.Size = new System.Drawing.Size(200, 22);
            this.txtService.TabIndex = 10;
            // 
            // txtAttendance
            // 
            this.txtAttendance.Location = new System.Drawing.Point(148, 176);
            this.txtAttendance.Name = "txtAttendance";
            this.txtAttendance.Size = new System.Drawing.Size(200, 22);
            this.txtAttendance.TabIndex = 9;
            // 
            // toolBar1
            // 
            this.toolBar1.AutoSize = false;
            this.toolBar1.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnAddAttendance,
            this.btnCancel});
            this.toolBar1.Dock = Wisej.Web.DockStyle.Bottom;
            this.toolBar1.Location = new System.Drawing.Point(0, 204);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(359, 55);
            this.toolBar1.TabIndex = 8;
            this.toolBar1.TabStop = false;
            // 
            // btnAddAttendance
            // 
            this.btnAddAttendance.ImageSource = "icon-new";
            this.btnAddAttendance.Name = "btnAddAttendance";
            this.btnAddAttendance.Text = "Add Attendance";
            this.btnAddAttendance.Click += new System.EventHandler(this.btnAddAttendance_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.ImageSource = "tab-close";
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 15);
            this.label7.TabIndex = 7;
            this.label7.Text = "Attendance";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 116);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 15);
            this.label6.TabIndex = 6;
            this.label6.Text = "Service";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "Church Attended";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Date ";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.btnViewChurchAttendance);
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Dock = Wisej.Web.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 35);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(866, 78);
            this.panel3.TabIndex = 1;
            this.panel3.TabStop = true;
            // 
            // btnViewChurchAttendance
            // 
            this.btnViewChurchAttendance.BackColor = System.Drawing.Color.Gainsboro;
            this.btnViewChurchAttendance.ForeColor = System.Drawing.Color.Black;
            this.btnViewChurchAttendance.Location = new System.Drawing.Point(688, 39);
            this.btnViewChurchAttendance.Name = "btnViewChurchAttendance";
            this.btnViewChurchAttendance.Size = new System.Drawing.Size(174, 27);
            this.btnViewChurchAttendance.TabIndex = 4;
            this.btnViewChurchAttendance.Text = "View Church Attendance";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel7.Controls.Add(this.cbView);
            this.panel7.Controls.Add(this.rbChurchMinistry);
            this.panel7.Controls.Add(this.rbServiceType);
            this.panel7.Controls.Add(this.rbGlobal);
            this.panel7.Location = new System.Drawing.Point(367, 5);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(314, 61);
            this.panel7.TabIndex = 3;
            this.panel7.TabStop = true;
            // 
            // cbView
            // 
            this.cbView.Location = new System.Drawing.Point(5, 30);
            this.cbView.Name = "cbView";
            this.cbView.Size = new System.Drawing.Size(302, 22);
            this.cbView.TabIndex = 6;
            // 
            // rbChurchMinistry
            // 
            this.rbChurchMinistry.AutoSize = false;
            this.rbChurchMinistry.Location = new System.Drawing.Point(177, 3);
            this.rbChurchMinistry.Name = "rbChurchMinistry";
            this.rbChurchMinistry.Size = new System.Drawing.Size(128, 22);
            this.rbChurchMinistry.TabIndex = 5;
            this.rbChurchMinistry.TabStop = true;
            this.rbChurchMinistry.Text = "Church / Ministry";
            // 
            // rbServiceType
            // 
            this.rbServiceType.Anchor = Wisej.Web.AnchorStyles.Left;
            this.rbServiceType.Location = new System.Drawing.Point(71, 3);
            this.rbServiceType.Name = "rbServiceType";
            this.rbServiceType.Size = new System.Drawing.Size(107, 22);
            this.rbServiceType.TabIndex = 1;
            this.rbServiceType.TabStop = true;
            this.rbServiceType.Text = "Service Type";
            // 
            // rbGlobal
            // 
            this.rbGlobal.Location = new System.Drawing.Point(3, 3);
            this.rbGlobal.Name = "rbGlobal";
            this.rbGlobal.Size = new System.Drawing.Size(69, 22);
            this.rbGlobal.TabIndex = 0;
            this.rbGlobal.TabStop = true;
            this.rbGlobal.Text = "Global";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.dtpDateTo);
            this.panel6.Controls.Add(this.dtpDateFrom);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Location = new System.Drawing.Point(12, 5);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(330, 61);
            this.panel6.TabIndex = 2;
            this.panel6.TabStop = true;
            // 
            // dtpDateTo
            // 
            this.dtpDateTo.Checked = false;
            this.dtpDateTo.Location = new System.Drawing.Point(173, 30);
            this.dtpDateTo.Name = "dtpDateTo";
            this.dtpDateTo.Size = new System.Drawing.Size(148, 22);
            this.dtpDateTo.TabIndex = 3;
            this.dtpDateTo.Value = new System.DateTime(2020, 10, 13, 17, 41, 34, 950);
            // 
            // dtpDateFrom
            // 
            this.dtpDateFrom.Checked = false;
            this.dtpDateFrom.Location = new System.Drawing.Point(6, 30);
            this.dtpDateFrom.Name = "dtpDateFrom";
            this.dtpDateFrom.Size = new System.Drawing.Size(151, 22);
            this.dtpDateFrom.TabIndex = 2;
            this.dtpDateFrom.Value = new System.DateTime(2020, 10, 13, 17, 41, 34, 950);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(184, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Date To";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Date From";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.ShowCloseButton = false;
            this.panel2.Size = new System.Drawing.Size(866, 35);
            this.panel2.TabIndex = 0;
            this.panel2.TabStop = true;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("default, Arial Black", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(12, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Church Attendance";
            // 
            // UCPrememberManager
            // 
            this.Controls.Add(this.panel1);
            this.Name = "UCPrememberManager";
            this.Size = new System.Drawing.Size(895, 443);
            this.Load += new System.EventHandler(this.UCPrememberManager_Load);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel7;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Button btnViewChurchAttendance;
        private Wisej.Web.DateTimePicker dtpDate;
        private Wisej.Web.ComboBox cbChurchAttended;
        private Wisej.Web.TextBox txtChurchAttended;
        private Wisej.Web.ComboBox cbService;
        private Wisej.Web.TextBox txtService;
        private Wisej.Web.TextBox txtAttendance;
        private Wisej.Web.ToolBar toolBar1;
        private Wisej.Web.ToolBarButton btnAddAttendance;
        private Wisej.Web.ToolBarButton btnCancel;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label4;
        private Wisej.Web.ComboBox cbView;
        private Wisej.Web.RadioButton rbChurchMinistry;
        private Wisej.Web.RadioButton rbServiceType;
        private Wisej.Web.RadioButton rbGlobal;
        private Wisej.Web.DateTimePicker dtpDateTo;
        private Wisej.Web.DateTimePicker dtpDateFrom;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label1;
    }
}
