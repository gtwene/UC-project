﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucPrememberManagerChuchAttendance : Wisej.Web.UserControl
    {
        public ucPrememberManagerChuchAttendance()
        {
            InitializeComponent();
        }

        private void UCPrememberManager_Load(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Controls.Clear();
        }

        private void btnAddAttendance_Click(object sender, EventArgs e)
        {
            try
            {
                if (Validate_Controls() == false)
                {
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Create Pre-member ?", GlobalValueCore.ApplicationName, MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {

                    if (CreatePreMember())
                    {

                        GlobalValueCore.InformationMessage("Pre member Created Successfully");
                        //CLEAR_TEXT();
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                    GlobalValueCore.InformationMessage("Cancelled by User");
                }
                //MessageBox.Show(""+branch.checkBranchName(txtBranchName.Text.ToString()));

            }
            catch (Exception ex)
            {
                GlobalValueCore.ExceptionMessage(ex.Message);
            }

        }



        private bool CreatePreMember()
        {
            throw new NotImplementedException();
        }

        private bool Validate_Controls()
        {

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtChurchAttended.Text, "Please Enter Church Attendance. Process Aborted !"))
            {
                txtChurchAttended.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtService.Text, "PLease Enter Service. Process Aborted !"))
            {
                txtService.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtAttendance.Text, "Please Enter Attendance. Process Aboretd !"))
            {
                txtAttendance.Select();
                return false;
            }

            return true;

            CLEAR_TEXT();
        }
        private void CLEAR_TEXT()
        {
            txtAttendance.Text = txtChurchAttended.Text = txtService.Text = "";
            cbChurchAttended.SelectedIndex = cbService.SelectedIndex = cbView.SelectedIndex = -1;
        }
    }
}
