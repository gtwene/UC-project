﻿namespace UCProject
{
    partial class ucPreMemberToMember
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel3 = new Wisej.Web.Panel();
            this.txtAnyCommentOnBaptism = new Wisej.Web.TextBox();
            this.dtpBaptizeDate = new Wisej.Web.DateTimePicker();
            this.label5 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.txtAnyCommentOnMembershipLesson = new Wisej.Web.TextBox();
            this.dtpDateCompletion = new Wisej.Web.DateTimePicker();
            this.label2 = new Wisej.Web.Label();
            this.ckHasPreMemberBeenBaptized = new Wisej.Web.CheckBox();
            this.ckHasPreMemberGone = new Wisej.Web.CheckBox();
            this.btnPreMemberToMember = new Wisej.Web.Button();
            this.btnCreateFirstTimerOrNewConvert = new Wisej.Web.Button();
            this.panel6 = new Wisej.Web.Panel();
            this.txtBusinessAddress = new Wisej.Web.TextBox();
            this.label32 = new Wisej.Web.Label();
            this.btnAdd = new Wisej.Web.Button();
            this.txtOccupation = new Wisej.Web.TextBox();
            this.cbOccupation = new Wisej.Web.ComboBox();
            this.label31 = new Wisej.Web.Label();
            this.txtNameOfEmployer = new Wisej.Web.TextBox();
            this.label30 = new Wisej.Web.Label();
            this.label29 = new Wisej.Web.Label();
            this.cbEmploymentStatus = new Wisej.Web.ComboBox();
            this.btnDelete = new Wisej.Web.Button();
            this.btnUpload = new Wisej.Web.Button();
            this.panel9 = new Wisej.Web.Panel();
            this.panel11 = new Wisej.Web.Panel();
            this.panel12 = new Wisej.Web.Panel();
            this.panel10 = new Wisej.Web.Panel();
            this.panel7 = new Wisej.Web.Panel();
            this.label39 = new Wisej.Web.Label();
            this.txtRoomNo = new Wisej.Web.TextBox();
            this.label38 = new Wisej.Web.Label();
            this.txtHall = new Wisej.Web.TextBox();
            this.label37 = new Wisej.Web.Label();
            this.cbResidentOnCampus = new Wisej.Web.ComboBox();
            this.label36 = new Wisej.Web.Label();
            this.txtLevelForm = new Wisej.Web.TextBox();
            this.label35 = new Wisej.Web.Label();
            this.txtProgramOfStudy = new Wisej.Web.TextBox();
            this.cbAcademicLevel = new Wisej.Web.ComboBox();
            this.label34 = new Wisej.Web.Label();
            this.label33 = new Wisej.Web.Label();
            this.txtNameOfStudent = new Wisej.Web.TextBox();
            this.panel8 = new Wisej.Web.Panel();
            this.panel5 = new Wisej.Web.Panel();
            this.label28 = new Wisej.Web.Label();
            this.label27 = new Wisej.Web.Label();
            this.cbNameOfCell = new Wisej.Web.ComboBox();
            this.cbInHomeCell = new Wisej.Web.ComboBox();
            this.cbAreaClassification = new Wisej.Web.ComboBox();
            this.label26 = new Wisej.Web.Label();
            this.ckSubureb = new Wisej.Web.CheckBox();
            this.txtTitheNo = new Wisej.Web.TextBox();
            this.label25 = new Wisej.Web.Label();
            this.cbWelfare = new Wisej.Web.ComboBox();
            this.label24 = new Wisej.Web.Label();
            this.label23 = new Wisej.Web.Label();
            this.cbDepartmemt = new Wisej.Web.ComboBox();
            this.label22 = new Wisej.Web.Label();
            this.cbInADepartment = new Wisej.Web.ComboBox();
            this.cbChurchMinistry = new Wisej.Web.ComboBox();
            this.label21 = new Wisej.Web.Label();
            this.panel4 = new Wisej.Web.Panel();
            this.label20 = new Wisej.Web.Label();
            this.txtResidentialAddress = new Wisej.Web.TextBox();
            this.dtpMarriageDate = new Wisej.Web.DateTimePicker();
            this.label19 = new Wisej.Web.Label();
            this.cbMaritalStatus = new Wisej.Web.ComboBox();
            this.label18 = new Wisej.Web.Label();
            this.txtEmail = new Wisej.Web.TextBox();
            this.label17 = new Wisej.Web.Label();
            this.txtTelephone = new Wisej.Web.TextBox();
            this.label16 = new Wisej.Web.Label();
            this.txtMobileNo = new Wisej.Web.TextBox();
            this.label15 = new Wisej.Web.Label();
            this.txtNationality = new Wisej.Web.TextBox();
            this.label14 = new Wisej.Web.Label();
            this.cbNationality = new Wisej.Web.ComboBox();
            this.label13 = new Wisej.Web.Label();
            this.cbYearJoined = new Wisej.Web.ComboBox();
            this.label12 = new Wisej.Web.Label();
            this.cbGender = new Wisej.Web.ComboBox();
            this.label11 = new Wisej.Web.Label();
            this.dtpDOB = new Wisej.Web.DateTimePicker();
            this.ckUseMemberRealAge = new Wisej.Web.CheckBox();
            this.label10 = new Wisej.Web.Label();
            this.txtOtherName = new Wisej.Web.TextBox();
            this.txtSurname = new Wisej.Web.TextBox();
            this.txtPreMemberRefNo = new Wisej.Web.TextBox();
            this.txtPreMemberType = new Wisej.Web.TextBox();
            this.label9 = new Wisej.Web.Label();
            this.label8 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.panel2 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.toolBar1 = new Wisej.Web.ToolBar();
            this.btnAddNewChuchMember = new Wisej.Web.ToolBarButton();
            this.btnCancel = new Wisej.Web.ToolBarButton();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.btnPreMemberToMember);
            this.panel1.Controls.Add(this.btnCreateFirstTimerOrNewConvert);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(893, 493);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            this.panel1.PanelCollapsed += new System.EventHandler(this.panel1_PanelCollapsed);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.txtAnyCommentOnBaptism);
            this.panel3.Controls.Add(this.dtpBaptizeDate);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.txtAnyCommentOnMembershipLesson);
            this.panel3.Controls.Add(this.dtpDateCompletion);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.ckHasPreMemberBeenBaptized);
            this.panel3.Controls.Add(this.ckHasPreMemberGone);
            this.panel3.ForeColor = System.Drawing.Color.Black;
            this.panel3.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel3.HeaderForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(3, 72);
            this.panel3.Name = "panel3";
            this.panel3.ShowCloseButton = false;
            this.panel3.ShowHeader = true;
            this.panel3.Size = new System.Drawing.Size(864, 238);
            this.panel3.TabIndex = 15;
            this.panel3.TabStop = true;
            this.panel3.Text = "New Pre-Members To Member";
            // 
            // txtAnyCommentOnBaptism
            // 
            this.txtAnyCommentOnBaptism.AutoSize = false;
            this.txtAnyCommentOnBaptism.LabelText = "";
            this.txtAnyCommentOnBaptism.Location = new System.Drawing.Point(244, 169);
            this.txtAnyCommentOnBaptism.Name = "txtAnyCommentOnBaptism";
            this.txtAnyCommentOnBaptism.Size = new System.Drawing.Size(556, 37);
            this.txtAnyCommentOnBaptism.TabIndex = 22;
            // 
            // dtpBaptizeDate
            // 
            this.dtpBaptizeDate.AutoSize = false;
            this.dtpBaptizeDate.Checked = false;
            this.dtpBaptizeDate.LabelText = "";
            this.dtpBaptizeDate.Location = new System.Drawing.Point(8, 169);
            this.dtpBaptizeDate.Name = "dtpBaptizeDate";
            this.dtpBaptizeDate.Size = new System.Drawing.Size(200, 37);
            this.dtpBaptizeDate.TabIndex = 21;
            this.dtpBaptizeDate.Value = new System.DateTime(2020, 10, 18, 17, 29, 15, 413);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 148);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(181, 15);
            this.label5.TabIndex = 20;
            this.label5.Text = "If Yes, Select Completion Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(244, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 15);
            this.label4.TabIndex = 19;
            this.label4.Text = "Any Comment On Baptism";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(244, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(234, 15);
            this.label3.TabIndex = 18;
            this.label3.Text = "Any Comment On Membership Lessons";
            // 
            // txtAnyCommentOnMembershipLesson
            // 
            this.txtAnyCommentOnMembershipLesson.AutoSize = false;
            this.txtAnyCommentOnMembershipLesson.LabelText = "";
            this.txtAnyCommentOnMembershipLesson.Location = new System.Drawing.Point(244, 70);
            this.txtAnyCommentOnMembershipLesson.Name = "txtAnyCommentOnMembershipLesson";
            this.txtAnyCommentOnMembershipLesson.Size = new System.Drawing.Size(556, 37);
            this.txtAnyCommentOnMembershipLesson.TabIndex = 17;
            // 
            // dtpDateCompletion
            // 
            this.dtpDateCompletion.AutoSize = false;
            this.dtpDateCompletion.Checked = false;
            this.dtpDateCompletion.LabelText = "";
            this.dtpDateCompletion.Location = new System.Drawing.Point(8, 73);
            this.dtpDateCompletion.Name = "dtpDateCompletion";
            this.dtpDateCompletion.Size = new System.Drawing.Size(200, 37);
            this.dtpDateCompletion.TabIndex = 16;
            this.dtpDateCompletion.Value = new System.DateTime(2020, 10, 18, 17, 29, 15, 413);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 15);
            this.label2.TabIndex = 15;
            this.label2.Text = "If Yes, Select Completion Date";
            // 
            // ckHasPreMemberBeenBaptized
            // 
            this.ckHasPreMemberBeenBaptized.Location = new System.Drawing.Point(8, 116);
            this.ckHasPreMemberBeenBaptized.Name = "ckHasPreMemberBeenBaptized";
            this.ckHasPreMemberBeenBaptized.Size = new System.Drawing.Size(217, 22);
            this.ckHasPreMemberBeenBaptized.TabIndex = 14;
            this.ckHasPreMemberBeenBaptized.Text = "Has Pre-Member been Baptized";
            // 
            // ckHasPreMemberGone
            // 
            this.ckHasPreMemberGone.Location = new System.Drawing.Point(8, 17);
            this.ckHasPreMemberGone.Name = "ckHasPreMemberGone";
            this.ckHasPreMemberGone.Size = new System.Drawing.Size(395, 22);
            this.ckHasPreMemberGone.TabIndex = 13;
            this.ckHasPreMemberGone.Text = "Has Pre-Member Gone Through Membership lessons / Class ?";
            // 
            // btnPreMemberToMember
            // 
            this.btnPreMemberToMember.BackColor = System.Drawing.Color.Gainsboro;
            this.btnPreMemberToMember.ForeColor = System.Drawing.Color.Black;
            this.btnPreMemberToMember.Location = new System.Drawing.Point(202, 44);
            this.btnPreMemberToMember.Name = "btnPreMemberToMember";
            this.btnPreMemberToMember.Size = new System.Drawing.Size(200, 27);
            this.btnPreMemberToMember.TabIndex = 14;
            this.btnPreMemberToMember.Text = "Pre-Member To Member";
            // 
            // btnCreateFirstTimerOrNewConvert
            // 
            this.btnCreateFirstTimerOrNewConvert.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCreateFirstTimerOrNewConvert.ForeColor = System.Drawing.Color.Black;
            this.btnCreateFirstTimerOrNewConvert.Location = new System.Drawing.Point(1, 44);
            this.btnCreateFirstTimerOrNewConvert.Name = "btnCreateFirstTimerOrNewConvert";
            this.btnCreateFirstTimerOrNewConvert.Size = new System.Drawing.Size(200, 27);
            this.btnCreateFirstTimerOrNewConvert.TabIndex = 13;
            this.btnCreateFirstTimerOrNewConvert.Text = "Pre-Member Search";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.txtBusinessAddress);
            this.panel6.Controls.Add(this.label32);
            this.panel6.Controls.Add(this.btnAdd);
            this.panel6.Controls.Add(this.txtOccupation);
            this.panel6.Controls.Add(this.cbOccupation);
            this.panel6.Controls.Add(this.label31);
            this.panel6.Controls.Add(this.txtNameOfEmployer);
            this.panel6.Controls.Add(this.label30);
            this.panel6.Controls.Add(this.label29);
            this.panel6.Controls.Add(this.cbEmploymentStatus);
            this.panel6.Controls.Add(this.btnDelete);
            this.panel6.Controls.Add(this.btnUpload);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Controls.Add(this.panel7);
            this.panel6.ForeColor = System.Drawing.Color.Black;
            this.panel6.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel6.HeaderForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(3, 764);
            this.panel6.Name = "panel6";
            this.panel6.ShowCloseButton = false;
            this.panel6.ShowHeader = true;
            this.panel6.Size = new System.Drawing.Size(864, 438);
            this.panel6.TabIndex = 4;
            this.panel6.TabStop = true;
            this.panel6.Text = "Employment Information";
            // 
            // txtBusinessAddress
            // 
            this.txtBusinessAddress.AutoSize = false;
            this.txtBusinessAddress.LabelText = "";
            this.txtBusinessAddress.Location = new System.Drawing.Point(302, 92);
            this.txtBusinessAddress.Name = "txtBusinessAddress";
            this.txtBusinessAddress.Size = new System.Drawing.Size(532, 39);
            this.txtBusinessAddress.TabIndex = 62;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(302, 70);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(108, 15);
            this.label32.TabIndex = 63;
            this.label32.Text = "Business Address";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Gainsboro;
            this.btnAdd.ForeColor = System.Drawing.Color.Black;
            this.btnAdd.ImageSource = "table-row-new";
            this.btnAdd.Location = new System.Drawing.Point(233, 75);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(47, 56);
            this.btnAdd.TabIndex = 61;
            // 
            // txtOccupation
            // 
            this.txtOccupation.LabelText = "";
            this.txtOccupation.Location = new System.Drawing.Point(3, 109);
            this.txtOccupation.Name = "txtOccupation";
            this.txtOccupation.Size = new System.Drawing.Size(224, 22);
            this.txtOccupation.TabIndex = 60;
            // 
            // cbOccupation
            // 
            this.cbOccupation.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbOccupation.Items.AddRange(new object[] {
            "Employed ",
            "Hired",
            "Self Employed",
            "Student ",
            "Trainee",
            "Unemployed"});
            this.cbOccupation.LabelText = "";
            this.cbOccupation.Location = new System.Drawing.Point(3, 81);
            this.cbOccupation.Name = "cbOccupation";
            this.cbOccupation.Size = new System.Drawing.Size(224, 22);
            this.cbOccupation.TabIndex = 59;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(10, 60);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(69, 15);
            this.label31.TabIndex = 58;
            this.label31.Text = "Occupation";
            // 
            // txtNameOfEmployer
            // 
            this.txtNameOfEmployer.LabelText = "";
            this.txtNameOfEmployer.Location = new System.Drawing.Point(301, 34);
            this.txtNameOfEmployer.Name = "txtNameOfEmployer";
            this.txtNameOfEmployer.Size = new System.Drawing.Size(532, 22);
            this.txtNameOfEmployer.TabIndex = 41;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(301, 13);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(191, 15);
            this.label30.TabIndex = 57;
            this.label30.Text = "Name OF Employer / Workplace";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(10, 13);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(116, 15);
            this.label29.TabIndex = 56;
            this.label29.Text = "Employment Status";
            // 
            // cbEmploymentStatus
            // 
            this.cbEmploymentStatus.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbEmploymentStatus.Items.AddRange(new object[] {
            "Employed ",
            "Hired",
            "Self Employed",
            "Student ",
            "Trainee",
            "Unemployed"});
            this.cbEmploymentStatus.LabelText = "";
            this.cbEmploymentStatus.Location = new System.Drawing.Point(3, 34);
            this.cbEmploymentStatus.Name = "cbEmploymentStatus";
            this.cbEmploymentStatus.Size = new System.Drawing.Size(277, 22);
            this.cbEmploymentStatus.TabIndex = 56;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Gainsboro;
            this.btnDelete.ForeColor = System.Drawing.Color.Black;
            this.btnDelete.Location = new System.Drawing.Point(741, 378);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(118, 27);
            this.btnDelete.TabIndex = 8;
            this.btnDelete.Text = "Delete Pic";
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.Gainsboro;
            this.btnUpload.ForeColor = System.Drawing.Color.Black;
            this.btnUpload.Location = new System.Drawing.Point(609, 378);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(114, 27);
            this.btnUpload.TabIndex = 7;
            this.btnUpload.Text = "Upload Picture";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel9.Controls.Add(this.panel11);
            this.panel9.Controls.Add(this.panel10);
            this.panel9.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel9.HeaderForeColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(609, 141);
            this.panel9.Name = "panel9";
            this.panel9.ShowCloseButton = false;
            this.panel9.ShowHeader = true;
            this.panel9.Size = new System.Drawing.Size(250, 233);
            this.panel9.TabIndex = 6;
            this.panel9.TabStop = true;
            this.panel9.Text = "Picture";
            // 
            // panel11
            // 
            this.panel11.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Location = new System.Drawing.Point(3, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(242, 197);
            this.panel11.TabIndex = 7;
            this.panel11.TabStop = true;
            // 
            // panel12
            // 
            this.panel12.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel12.Location = new System.Drawing.Point(623, -1);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(228, 180);
            this.panel12.TabIndex = 5;
            this.panel12.TabStop = true;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel10.Location = new System.Drawing.Point(623, -1);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(228, 180);
            this.panel10.TabIndex = 5;
            this.panel10.TabStop = true;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel7.Controls.Add(this.label39);
            this.panel7.Controls.Add(this.txtRoomNo);
            this.panel7.Controls.Add(this.label38);
            this.panel7.Controls.Add(this.txtHall);
            this.panel7.Controls.Add(this.label37);
            this.panel7.Controls.Add(this.cbResidentOnCampus);
            this.panel7.Controls.Add(this.label36);
            this.panel7.Controls.Add(this.txtLevelForm);
            this.panel7.Controls.Add(this.label35);
            this.panel7.Controls.Add(this.txtProgramOfStudy);
            this.panel7.Controls.Add(this.cbAcademicLevel);
            this.panel7.Controls.Add(this.label34);
            this.panel7.Controls.Add(this.label33);
            this.panel7.Controls.Add(this.txtNameOfStudent);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel7.HeaderForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(3, 141);
            this.panel7.Name = "panel7";
            this.panel7.ShowCloseButton = false;
            this.panel7.ShowHeader = true;
            this.panel7.Size = new System.Drawing.Size(600, 267);
            this.panel7.TabIndex = 4;
            this.panel7.TabStop = true;
            this.panel7.Text = "If Student";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(519, 136);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(58, 15);
            this.label39.TabIndex = 75;
            this.label39.Text = "Room No";
            // 
            // txtRoomNo
            // 
            this.txtRoomNo.LabelText = "";
            this.txtRoomNo.Location = new System.Drawing.Point(519, 157);
            this.txtRoomNo.Name = "txtRoomNo";
            this.txtRoomNo.Size = new System.Drawing.Size(70, 22);
            this.txtRoomNo.TabIndex = 74;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(298, 136);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(140, 15);
            this.label38.TabIndex = 73;
            this.label38.Text = "If Yes, Hall Of Affiliation";
            // 
            // txtHall
            // 
            this.txtHall.LabelText = "";
            this.txtHall.Location = new System.Drawing.Point(298, 157);
            this.txtHall.Name = "txtHall";
            this.txtHall.Size = new System.Drawing.Size(215, 22);
            this.txtHall.TabIndex = 72;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(6, 136);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(139, 15);
            this.label37.TabIndex = 71;
            this.label37.Text = "Resident On Campus ?";
            // 
            // cbResidentOnCampus
            // 
            this.cbResidentOnCampus.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbResidentOnCampus.Items.AddRange(new object[] {
            "JHS",
            "Polytechnic",
            "Professional / Vocational School",
            "SHS",
            "University"});
            this.cbResidentOnCampus.LabelText = "";
            this.cbResidentOnCampus.Location = new System.Drawing.Point(6, 157);
            this.cbResidentOnCampus.Name = "cbResidentOnCampus";
            this.cbResidentOnCampus.Size = new System.Drawing.Size(271, 22);
            this.cbResidentOnCampus.TabIndex = 70;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(298, 71);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(76, 15);
            this.label36.TabIndex = 68;
            this.label36.Text = "Level / Form";
            // 
            // txtLevelForm
            // 
            this.txtLevelForm.LabelText = "";
            this.txtLevelForm.Location = new System.Drawing.Point(298, 92);
            this.txtLevelForm.Name = "txtLevelForm";
            this.txtLevelForm.Size = new System.Drawing.Size(291, 22);
            this.txtLevelForm.TabIndex = 69;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(6, 71);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(108, 15);
            this.label35.TabIndex = 66;
            this.label35.Text = "Program Of Study";
            // 
            // txtProgramOfStudy
            // 
            this.txtProgramOfStudy.LabelText = "";
            this.txtProgramOfStudy.Location = new System.Drawing.Point(6, 92);
            this.txtProgramOfStudy.Name = "txtProgramOfStudy";
            this.txtProgramOfStudy.Size = new System.Drawing.Size(270, 22);
            this.txtProgramOfStudy.TabIndex = 67;
            // 
            // cbAcademicLevel
            // 
            this.cbAcademicLevel.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbAcademicLevel.Items.AddRange(new object[] {
            "JHS",
            "Polytechnic",
            "Professional / Vocational School",
            "SHS",
            "University"});
            this.cbAcademicLevel.LabelText = "";
            this.cbAcademicLevel.Location = new System.Drawing.Point(297, 27);
            this.cbAcademicLevel.Name = "cbAcademicLevel";
            this.cbAcademicLevel.Size = new System.Drawing.Size(292, 22);
            this.cbAcademicLevel.TabIndex = 64;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(297, 7);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(95, 15);
            this.label34.TabIndex = 65;
            this.label34.Text = "Academic Level";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 7);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(104, 15);
            this.label33.TabIndex = 64;
            this.label33.Text = "Name Of Student";
            // 
            // txtNameOfStudent
            // 
            this.txtNameOfStudent.LabelText = "";
            this.txtNameOfStudent.Location = new System.Drawing.Point(6, 28);
            this.txtNameOfStudent.Name = "txtNameOfStudent";
            this.txtNameOfStudent.Size = new System.Drawing.Size(270, 22);
            this.txtNameOfStudent.TabIndex = 64;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel8.Location = new System.Drawing.Point(623, -1);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(228, 180);
            this.panel8.TabIndex = 5;
            this.panel8.TabStop = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.label28);
            this.panel5.Controls.Add(this.label27);
            this.panel5.Controls.Add(this.cbNameOfCell);
            this.panel5.Controls.Add(this.cbInHomeCell);
            this.panel5.Controls.Add(this.cbAreaClassification);
            this.panel5.Controls.Add(this.label26);
            this.panel5.Controls.Add(this.ckSubureb);
            this.panel5.Controls.Add(this.txtTitheNo);
            this.panel5.Controls.Add(this.label25);
            this.panel5.Controls.Add(this.cbWelfare);
            this.panel5.Controls.Add(this.label24);
            this.panel5.Controls.Add(this.label23);
            this.panel5.Controls.Add(this.cbDepartmemt);
            this.panel5.Controls.Add(this.label22);
            this.panel5.Controls.Add(this.cbInADepartment);
            this.panel5.Controls.Add(this.cbChurchMinistry);
            this.panel5.Controls.Add(this.label21);
            this.panel5.ForeColor = System.Drawing.Color.Black;
            this.panel5.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel5.HeaderForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(3, 595);
            this.panel5.Name = "panel5";
            this.panel5.ShowCloseButton = false;
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(864, 163);
            this.panel5.TabIndex = 3;
            this.panel5.TabStop = true;
            this.panel5.Text = "Church && Departmental Information";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(695, 79);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(160, 15);
            this.label28.TabIndex = 55;
            this.label28.Text = "If Yes, Name Of Home Cell";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(529, 79);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(89, 15);
            this.label27.TabIndex = 54;
            this.label27.Text = "In Home Cell ?";
            // 
            // cbNameOfCell
            // 
            this.cbNameOfCell.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbNameOfCell.Items.AddRange(new object[] {
            "Adult Service - Perez Dome",
            "French Service",
            "Timothy Generation",
            "Twi Service"});
            this.cbNameOfCell.LabelText = "";
            this.cbNameOfCell.Location = new System.Drawing.Point(696, 100);
            this.cbNameOfCell.Name = "cbNameOfCell";
            this.cbNameOfCell.Size = new System.Drawing.Size(159, 22);
            this.cbNameOfCell.TabIndex = 53;
            // 
            // cbInHomeCell
            // 
            this.cbInHomeCell.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbInHomeCell.Items.AddRange(new object[] {
            "Adult Service - Perez Dome",
            "French Service",
            "Timothy Generation",
            "Twi Service"});
            this.cbInHomeCell.LabelText = "";
            this.cbInHomeCell.Location = new System.Drawing.Point(529, 100);
            this.cbInHomeCell.Name = "cbInHomeCell";
            this.cbInHomeCell.Size = new System.Drawing.Size(159, 22);
            this.cbInHomeCell.TabIndex = 52;
            // 
            // cbAreaClassification
            // 
            this.cbAreaClassification.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbAreaClassification.Items.AddRange(new object[] {
            "Adult Service - Perez Dome",
            "French Service",
            "Timothy Generation",
            "Twi Service"});
            this.cbAreaClassification.LabelText = "";
            this.cbAreaClassification.Location = new System.Drawing.Point(3, 100);
            this.cbAreaClassification.Name = "cbAreaClassification";
            this.cbAreaClassification.Size = new System.Drawing.Size(514, 22);
            this.cbAreaClassification.TabIndex = 51;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 79);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(164, 15);
            this.label26.TabIndex = 50;
            this.label26.Text = "Suburb / Area Classification";
            // 
            // ckSubureb
            // 
            this.ckSubureb.Location = new System.Drawing.Point(10, 51);
            this.ckSubureb.Name = "ckSubureb";
            this.ckSubureb.Size = new System.Drawing.Size(428, 22);
            this.ckSubureb.TabIndex = 49;
            this.ckSubureb.Text = "Suburb / Area Classification not available at the time of Data Capture";
            // 
            // txtTitheNo
            // 
            this.txtTitheNo.LabelText = "";
            this.txtTitheNo.Location = new System.Drawing.Point(741, 25);
            this.txtTitheNo.Name = "txtTitheNo";
            this.txtTitheNo.Size = new System.Drawing.Size(103, 22);
            this.txtTitheNo.TabIndex = 41;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(741, 3);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 15);
            this.label25.TabIndex = 48;
            this.label25.Text = "Tithe No";
            // 
            // cbWelfare
            // 
            this.cbWelfare.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbWelfare.Items.AddRange(new object[] {
            "Adult Service - Perez Dome",
            "French Service",
            "Timothy Generation",
            "Twi Service"});
            this.cbWelfare.LabelText = "";
            this.cbWelfare.Location = new System.Drawing.Point(529, 24);
            this.cbWelfare.Name = "cbWelfare";
            this.cbWelfare.Size = new System.Drawing.Size(194, 22);
            this.cbWelfare.TabIndex = 47;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(529, 3);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(119, 15);
            this.label24.TabIndex = 46;
            this.label24.Text = "In Church Welfare ?";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(325, 3);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(82, 15);
            this.label23.TabIndex = 45;
            this.label23.Text = "Department ?";
            // 
            // cbDepartmemt
            // 
            this.cbDepartmemt.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbDepartmemt.Items.AddRange(new object[] {
            "Adult Service - Perez Dome",
            "French Service",
            "Timothy Generation",
            "Twi Service"});
            this.cbDepartmemt.LabelText = "";
            this.cbDepartmemt.Location = new System.Drawing.Point(325, 24);
            this.cbDepartmemt.Name = "cbDepartmemt";
            this.cbDepartmemt.Size = new System.Drawing.Size(194, 22);
            this.cbDepartmemt.TabIndex = 44;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(211, 3);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(108, 15);
            this.label22.TabIndex = 43;
            this.label22.Text = "In a Department ?";
            // 
            // cbInADepartment
            // 
            this.cbInADepartment.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbInADepartment.Items.AddRange(new object[] {
            "Adult Service - Perez Dome",
            "French Service",
            "Timothy Generation",
            "Twi Service"});
            this.cbInADepartment.LabelText = "";
            this.cbInADepartment.Location = new System.Drawing.Point(211, 24);
            this.cbInADepartment.Name = "cbInADepartment";
            this.cbInADepartment.Size = new System.Drawing.Size(108, 22);
            this.cbInADepartment.TabIndex = 42;
            // 
            // cbChurchMinistry
            // 
            this.cbChurchMinistry.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbChurchMinistry.Items.AddRange(new object[] {
            "Adult Service - Perez Dome",
            "French Service",
            "Timothy Generation",
            "Twi Service"});
            this.cbChurchMinistry.LabelText = "";
            this.cbChurchMinistry.Location = new System.Drawing.Point(10, 24);
            this.cbChurchMinistry.Name = "cbChurchMinistry";
            this.cbChurchMinistry.Size = new System.Drawing.Size(194, 22);
            this.cbChurchMinistry.TabIndex = 41;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(10, 3);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(101, 15);
            this.label21.TabIndex = 41;
            this.label21.Text = "Church / Ministry";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.txtResidentialAddress);
            this.panel4.Controls.Add(this.dtpMarriageDate);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Controls.Add(this.cbMaritalStatus);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.txtEmail);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.txtTelephone);
            this.panel4.Controls.Add(this.label16);
            this.panel4.Controls.Add(this.txtMobileNo);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.txtNationality);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.cbNationality);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.cbYearJoined);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.cbGender);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.dtpDOB);
            this.panel4.Controls.Add(this.ckUseMemberRealAge);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.txtOtherName);
            this.panel4.Controls.Add(this.txtSurname);
            this.panel4.Controls.Add(this.txtPreMemberRefNo);
            this.panel4.Controls.Add(this.txtPreMemberType);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label6);
            this.panel4.ForeColor = System.Drawing.Color.Black;
            this.panel4.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel4.HeaderForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(3, 316);
            this.panel4.Name = "panel4";
            this.panel4.ShowCloseButton = false;
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(864, 273);
            this.panel4.TabIndex = 2;
            this.panel4.TabStop = true;
            this.panel4.Text = "Personal Information";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(314, 171);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(119, 15);
            this.label20.TabIndex = 40;
            this.label20.Text = "Residential Address";
            // 
            // txtResidentialAddress
            // 
            this.txtResidentialAddress.LabelText = "";
            this.txtResidentialAddress.Location = new System.Drawing.Point(312, 195);
            this.txtResidentialAddress.Name = "txtResidentialAddress";
            this.txtResidentialAddress.Size = new System.Drawing.Size(532, 22);
            this.txtResidentialAddress.TabIndex = 39;
            // 
            // dtpMarriageDate
            // 
            this.dtpMarriageDate.Checked = false;
            this.dtpMarriageDate.LabelText = "";
            this.dtpMarriageDate.Location = new System.Drawing.Point(145, 192);
            this.dtpMarriageDate.Name = "dtpMarriageDate";
            this.dtpMarriageDate.Size = new System.Drawing.Size(151, 22);
            this.dtpMarriageDate.TabIndex = 38;
            this.dtpMarriageDate.Value = new System.DateTime(2020, 10, 18, 17, 29, 15, 413);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(141, 171);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(155, 15);
            this.label19.TabIndex = 37;
            this.label19.Text = "If Married ? Marriage Date";
            // 
            // cbMaritalStatus
            // 
            this.cbMaritalStatus.LabelText = "";
            this.cbMaritalStatus.Location = new System.Drawing.Point(10, 194);
            this.cbMaritalStatus.Name = "cbMaritalStatus";
            this.cbMaritalStatus.Size = new System.Drawing.Size(127, 22);
            this.cbMaritalStatus.TabIndex = 36;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 173);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 15);
            this.label18.TabIndex = 35;
            this.label18.Text = "Marital Status";
            // 
            // txtEmail
            // 
            this.txtEmail.LabelText = "";
            this.txtEmail.Location = new System.Drawing.Point(578, 145);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(266, 22);
            this.txtEmail.TabIndex = 34;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(578, 124);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 15);
            this.label17.TabIndex = 33;
            this.label17.Text = "Email";
            // 
            // txtTelephone
            // 
            this.txtTelephone.LabelText = "";
            this.txtTelephone.Location = new System.Drawing.Point(314, 145);
            this.txtTelephone.Name = "txtTelephone";
            this.txtTelephone.Size = new System.Drawing.Size(256, 22);
            this.txtTelephone.TabIndex = 32;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(314, 124);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(80, 15);
            this.label16.TabIndex = 31;
            this.label16.Text = "Telephone(s)";
            // 
            // txtMobileNo
            // 
            this.txtMobileNo.LabelText = "";
            this.txtMobileNo.Location = new System.Drawing.Point(10, 145);
            this.txtMobileNo.Name = "txtMobileNo";
            this.txtMobileNo.Size = new System.Drawing.Size(286, 22);
            this.txtMobileNo.TabIndex = 30;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 124);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 15);
            this.label15.TabIndex = 29;
            this.label15.Text = "Mobile No.";
            // 
            // txtNationality
            // 
            this.txtNationality.LabelText = "";
            this.txtNationality.Location = new System.Drawing.Point(711, 90);
            this.txtNationality.Name = "txtNationality";
            this.txtNationality.Size = new System.Drawing.Size(133, 22);
            this.txtNationality.TabIndex = 28;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(711, 70);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(64, 15);
            this.label14.TabIndex = 27;
            this.label14.Text = "Nationality";
            // 
            // cbNationality
            // 
            this.cbNationality.LabelText = "";
            this.cbNationality.Location = new System.Drawing.Point(578, 90);
            this.cbNationality.Name = "cbNationality";
            this.cbNationality.Size = new System.Drawing.Size(127, 22);
            this.cbNationality.TabIndex = 26;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(578, 70);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 15);
            this.label13.TabIndex = 25;
            this.label13.Text = "Nationality";
            // 
            // cbYearJoined
            // 
            this.cbYearJoined.LabelText = "";
            this.cbYearJoined.Location = new System.Drawing.Point(444, 90);
            this.cbYearJoined.Name = "cbYearJoined";
            this.cbYearJoined.Size = new System.Drawing.Size(127, 22);
            this.cbYearJoined.TabIndex = 24;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(444, 70);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 15);
            this.label12.TabIndex = 23;
            this.label12.Text = "Year Joined";
            // 
            // cbGender
            // 
            this.cbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cbGender.LabelText = "";
            this.cbGender.Location = new System.Drawing.Point(312, 90);
            this.cbGender.Name = "cbGender";
            this.cbGender.Size = new System.Drawing.Size(127, 22);
            this.cbGender.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(312, 70);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 15);
            this.label11.TabIndex = 21;
            this.label11.Text = "Gender";
            // 
            // dtpDOB
            // 
            this.dtpDOB.Checked = false;
            this.dtpDOB.LabelText = "";
            this.dtpDOB.Location = new System.Drawing.Point(10, 91);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(286, 22);
            this.dtpDOB.TabIndex = 13;
            this.dtpDOB.Value = new System.DateTime(2020, 10, 18, 17, 29, 15, 413);
            // 
            // ckUseMemberRealAge
            // 
            this.ckUseMemberRealAge.Location = new System.Drawing.Point(104, 67);
            this.ckUseMemberRealAge.Name = "ckUseMemberRealAge";
            this.ckUseMemberRealAge.Size = new System.Drawing.Size(163, 22);
            this.ckUseMemberRealAge.TabIndex = 13;
            this.ckUseMemberRealAge.Text = "Use Member Real Age";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 70);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 15);
            this.label10.TabIndex = 20;
            this.label10.Text = "DOB(Age)";
            // 
            // txtOtherName
            // 
            this.txtOtherName.LabelText = "";
            this.txtOtherName.Location = new System.Drawing.Point(564, 36);
            this.txtOtherName.Name = "txtOtherName";
            this.txtOtherName.Size = new System.Drawing.Size(235, 22);
            this.txtOtherName.TabIndex = 19;
            // 
            // txtSurname
            // 
            this.txtSurname.LabelText = "";
            this.txtSurname.Location = new System.Drawing.Point(314, 36);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(236, 22);
            this.txtSurname.TabIndex = 18;
            // 
            // txtPreMemberRefNo
            // 
            this.txtPreMemberRefNo.LabelText = "";
            this.txtPreMemberRefNo.Location = new System.Drawing.Point(189, 36);
            this.txtPreMemberRefNo.Name = "txtPreMemberRefNo";
            this.txtPreMemberRefNo.Size = new System.Drawing.Size(107, 22);
            this.txtPreMemberRefNo.TabIndex = 17;
            // 
            // txtPreMemberType
            // 
            this.txtPreMemberType.LabelText = "";
            this.txtPreMemberType.Location = new System.Drawing.Point(10, 36);
            this.txtPreMemberType.Name = "txtPreMemberType";
            this.txtPreMemberType.Size = new System.Drawing.Size(172, 22);
            this.txtPreMemberType.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(564, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "Other Names";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(314, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 15);
            this.label8.TabIndex = 15;
            this.label8.Text = "Surname";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(189, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "Pre-Member Ref No.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "Pre-Member Type";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(874, 43);
            this.panel2.TabIndex = 0;
            this.panel2.TabStop = true;
            this.panel2.PanelCollapsed += new System.EventHandler(this.panel2_PanelCollapsed);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("default, Arial Black", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(281, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "New Pre-members To Member :";
            // 
            // toolBar1
            // 
            this.toolBar1.AutoSize = false;
            this.toolBar1.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnAddNewChuchMember,
            this.btnCancel});
            this.toolBar1.Dock = Wisej.Web.DockStyle.Bottom;
            this.toolBar1.Location = new System.Drawing.Point(0, 495);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(898, 49);
            this.toolBar1.TabIndex = 6;
            this.toolBar1.TabStop = false;
            // 
            // btnAddNewChuchMember
            // 
            this.btnAddNewChuchMember.ImageSource = "icon-new";
            this.btnAddNewChuchMember.Name = "btnAddNewChuchMember";
            this.btnAddNewChuchMember.Text = "Add New Church Member";
            this.btnAddNewChuchMember.Click += new System.EventHandler(this.btnAddNewChuchMember_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.ImageSource = "icon-close";
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Text = "Cancel";
            // 
            // ucPreMemberToMember
            // 
            this.Controls.Add(this.toolBar1);
            this.Controls.Add(this.panel1);
            this.Name = "ucPreMemberToMember";
            this.Size = new System.Drawing.Size(898, 544);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.Panel panel9;
        private Wisej.Web.Panel panel10;
        private Wisej.Web.Panel panel7;
        private Wisej.Web.Panel panel8;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Button btnDelete;
        private Wisej.Web.Button btnUpload;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label1;
        private Wisej.Web.Button btnPreMemberToMember;
        private Wisej.Web.Button btnCreateFirstTimerOrNewConvert;
        private Wisej.Web.Panel panel11;
        private Wisej.Web.Panel panel12;
        private Wisej.Web.Label label20;
        private Wisej.Web.TextBox txtResidentialAddress;
        private Wisej.Web.DateTimePicker dtpMarriageDate;
        private Wisej.Web.Label label19;
        private Wisej.Web.ComboBox cbMaritalStatus;
        private Wisej.Web.Label label18;
        private Wisej.Web.TextBox txtEmail;
        private Wisej.Web.Label label17;
        private Wisej.Web.TextBox txtTelephone;
        private Wisej.Web.Label label16;
        private Wisej.Web.TextBox txtMobileNo;
        private Wisej.Web.Label label15;
        private Wisej.Web.TextBox txtNationality;
        private Wisej.Web.Label label14;
        private Wisej.Web.ComboBox cbNationality;
        private Wisej.Web.Label label13;
        private Wisej.Web.ComboBox cbYearJoined;
        private Wisej.Web.Label label12;
        private Wisej.Web.ComboBox cbGender;
        private Wisej.Web.Label label11;
        private Wisej.Web.DateTimePicker dtpDOB;
        private Wisej.Web.CheckBox ckUseMemberRealAge;
        private Wisej.Web.Label label10;
        private Wisej.Web.TextBox txtOtherName;
        private Wisej.Web.TextBox txtSurname;
        private Wisej.Web.TextBox txtPreMemberRefNo;
        private Wisej.Web.TextBox txtPreMemberType;
        private Wisej.Web.Label label9;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label6;
        private Wisej.Web.TextBox txtBusinessAddress;
        private Wisej.Web.Label label32;
        private Wisej.Web.Button btnAdd;
        private Wisej.Web.TextBox txtOccupation;
        private Wisej.Web.ComboBox cbOccupation;
        private Wisej.Web.Label label31;
        private Wisej.Web.TextBox txtNameOfEmployer;
        private Wisej.Web.Label label30;
        private Wisej.Web.Label label29;
        private Wisej.Web.ComboBox cbEmploymentStatus;
        private Wisej.Web.Label label39;
        private Wisej.Web.TextBox txtRoomNo;
        private Wisej.Web.Label label38;
        private Wisej.Web.TextBox txtHall;
        private Wisej.Web.Label label37;
        private Wisej.Web.ComboBox cbResidentOnCampus;
        private Wisej.Web.Label label36;
        private Wisej.Web.TextBox txtLevelForm;
        private Wisej.Web.Label label35;
        private Wisej.Web.TextBox txtProgramOfStudy;
        private Wisej.Web.ComboBox cbAcademicLevel;
        private Wisej.Web.Label label34;
        private Wisej.Web.Label label33;
        private Wisej.Web.TextBox txtNameOfStudent;
        private Wisej.Web.Label label28;
        private Wisej.Web.Label label27;
        private Wisej.Web.ComboBox cbNameOfCell;
        private Wisej.Web.ComboBox cbInHomeCell;
        private Wisej.Web.ComboBox cbAreaClassification;
        private Wisej.Web.Label label26;
        private Wisej.Web.CheckBox ckSubureb;
        private Wisej.Web.TextBox txtTitheNo;
        private Wisej.Web.Label label25;
        private Wisej.Web.ComboBox cbWelfare;
        private Wisej.Web.Label label24;
        private Wisej.Web.Label label23;
        private Wisej.Web.ComboBox cbDepartmemt;
        private Wisej.Web.Label label22;
        private Wisej.Web.ComboBox cbInADepartment;
        private Wisej.Web.ComboBox cbChurchMinistry;
        private Wisej.Web.Label label21;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.TextBox txtAnyCommentOnBaptism;
        private Wisej.Web.DateTimePicker dtpBaptizeDate;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label3;
        private Wisej.Web.TextBox txtAnyCommentOnMembershipLesson;
        private Wisej.Web.DateTimePicker dtpDateCompletion;
        private Wisej.Web.Label label2;
        private Wisej.Web.CheckBox ckHasPreMemberBeenBaptized;
        private Wisej.Web.CheckBox ckHasPreMemberGone;
        private Wisej.Web.ToolBar toolBar1;
        private Wisej.Web.ToolBarButton btnAddNewChuchMember;
        private Wisej.Web.ToolBarButton btnCancel;
    }
}
