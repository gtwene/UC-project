﻿namespace UCProject
{
    partial class ucExistingMember
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PExistingMembers = new Wisej.Web.Panel();
            this.btnExistingMembers = new Wisej.Web.Button();
            this.btnCreateFirstTimerOrNewConvert = new Wisej.Web.Button();
            this.btnFirstTimeNewConvert = new Wisej.Web.Button();
            this.panel3 = new Wisej.Web.Panel();
            this.txtSearchCriteria = new Wisej.Web.TextBox();
            this.panel4 = new Wisej.Web.Panel();
            this.btnViewMembers = new Wisej.Web.Button();
            this.txtViewMembers = new Wisej.Web.TextBox();
            this.cbSearchCriteri = new Wisej.Web.ComboBox();
            this.label2 = new Wisej.Web.Label();
            this.rbDepartmemt = new Wisej.Web.RadioButton();
            this.rbMemberType = new Wisej.Web.RadioButton();
            this.rbGlobal = new Wisej.Web.RadioButton();
            this.panel2 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.PExistingMembers.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // PExistingMembers
            // 
            this.PExistingMembers.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Left) 
            | Wisej.Web.AnchorStyles.Right)));
            this.PExistingMembers.AutoScroll = true;
            this.PExistingMembers.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.PExistingMembers.Controls.Add(this.btnExistingMembers);
            this.PExistingMembers.Controls.Add(this.btnCreateFirstTimerOrNewConvert);
            this.PExistingMembers.Controls.Add(this.btnFirstTimeNewConvert);
            this.PExistingMembers.Controls.Add(this.panel3);
            this.PExistingMembers.Controls.Add(this.panel2);
            this.PExistingMembers.Location = new System.Drawing.Point(10, 24);
            this.PExistingMembers.Name = "PExistingMembers";
            this.PExistingMembers.Size = new System.Drawing.Size(889, 401);
            this.PExistingMembers.TabIndex = 0;
            this.PExistingMembers.TabStop = true;
            // 
            // btnExistingMembers
            // 
            this.btnExistingMembers.BackColor = System.Drawing.Color.Gainsboro;
            this.btnExistingMembers.ForeColor = System.Drawing.Color.Black;
            this.btnExistingMembers.Location = new System.Drawing.Point(401, 34);
            this.btnExistingMembers.Name = "btnExistingMembers";
            this.btnExistingMembers.Size = new System.Drawing.Size(200, 27);
            this.btnExistingMembers.TabIndex = 10;
            this.btnExistingMembers.Text = "Existing Members";
            this.btnExistingMembers.Click += new System.EventHandler(this.btnExistingMembers_Click);
            // 
            // btnCreateFirstTimerOrNewConvert
            // 
            this.btnCreateFirstTimerOrNewConvert.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCreateFirstTimerOrNewConvert.ForeColor = System.Drawing.Color.Black;
            this.btnCreateFirstTimerOrNewConvert.Location = new System.Drawing.Point(200, 34);
            this.btnCreateFirstTimerOrNewConvert.Name = "btnCreateFirstTimerOrNewConvert";
            this.btnCreateFirstTimerOrNewConvert.Size = new System.Drawing.Size(200, 27);
            this.btnCreateFirstTimerOrNewConvert.TabIndex = 9;
            this.btnCreateFirstTimerOrNewConvert.Text = "Create First Time Or New Convert";
            this.btnCreateFirstTimerOrNewConvert.Click += new System.EventHandler(this.btnCreateFirstTimerOrNewConvert_Click);
            // 
            // btnFirstTimeNewConvert
            // 
            this.btnFirstTimeNewConvert.BackColor = System.Drawing.Color.Gainsboro;
            this.btnFirstTimeNewConvert.ForeColor = System.Drawing.Color.Black;
            this.btnFirstTimeNewConvert.Location = new System.Drawing.Point(-1, 34);
            this.btnFirstTimeNewConvert.Name = "btnFirstTimeNewConvert";
            this.btnFirstTimeNewConvert.Size = new System.Drawing.Size(200, 27);
            this.btnFirstTimeNewConvert.TabIndex = 8;
            this.btnFirstTimeNewConvert.Text = "First Time / New Convert Search";
            this.btnFirstTimeNewConvert.Click += new System.EventHandler(this.btnFirstTimeNewConvert_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.txtSearchCriteria);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.btnViewMembers);
            this.panel3.Controls.Add(this.txtViewMembers);
            this.panel3.Controls.Add(this.cbSearchCriteri);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.rbDepartmemt);
            this.panel3.Controls.Add(this.rbMemberType);
            this.panel3.Controls.Add(this.rbGlobal);
            this.panel3.Location = new System.Drawing.Point(2, 62);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(865, 428);
            this.panel3.TabIndex = 4;
            this.panel3.TabStop = true;
            // 
            // txtSearchCriteria
            // 
            this.txtSearchCriteria.Location = new System.Drawing.Point(711, 21);
            this.txtSearchCriteria.Name = "txtSearchCriteria";
            this.txtSearchCriteria.Size = new System.Drawing.Size(68, 22);
            this.txtSearchCriteria.TabIndex = 8;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel4.HeaderForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(3, 112);
            this.panel4.Name = "panel4";
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(857, 311);
            this.panel4.TabIndex = 7;
            this.panel4.TabStop = true;
            this.panel4.Text = "Search Results";
            // 
            // btnViewMembers
            // 
            this.btnViewMembers.BackColor = System.Drawing.Color.Gainsboro;
            this.btnViewMembers.ForeColor = System.Drawing.Color.Black;
            this.btnViewMembers.ImageSource = "icon-search";
            this.btnViewMembers.Location = new System.Drawing.Point(296, 70);
            this.btnViewMembers.Name = "btnViewMembers";
            this.btnViewMembers.Size = new System.Drawing.Size(174, 27);
            this.btnViewMembers.TabIndex = 6;
            this.btnViewMembers.Text = "View Members";
            // 
            // txtViewMembers
            // 
            this.txtViewMembers.Location = new System.Drawing.Point(32, 71);
            this.txtViewMembers.Name = "txtViewMembers";
            this.txtViewMembers.Size = new System.Drawing.Size(183, 22);
            this.txtViewMembers.TabIndex = 5;
            // 
            // cbSearchCriteri
            // 
            this.cbSearchCriteri.Location = new System.Drawing.Point(562, 21);
            this.cbSearchCriteri.Name = "cbSearchCriteri";
            this.cbSearchCriteri.Size = new System.Drawing.Size(143, 22);
            this.cbSearchCriteri.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(467, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Search Criteria";
            // 
            // rbDepartmemt
            // 
            this.rbDepartmemt.Location = new System.Drawing.Point(286, 22);
            this.rbDepartmemt.Name = "rbDepartmemt";
            this.rbDepartmemt.Size = new System.Drawing.Size(103, 22);
            this.rbDepartmemt.TabIndex = 2;
            this.rbDepartmemt.TabStop = true;
            this.rbDepartmemt.Text = "Departmemt";
            // 
            // rbMemberType
            // 
            this.rbMemberType.Location = new System.Drawing.Point(131, 22);
            this.rbMemberType.Name = "rbMemberType";
            this.rbMemberType.Size = new System.Drawing.Size(112, 22);
            this.rbMemberType.TabIndex = 1;
            this.rbMemberType.TabStop = true;
            this.rbMemberType.Text = "Member Type";
            // 
            // rbGlobal
            // 
            this.rbGlobal.Location = new System.Drawing.Point(32, 22);
            this.rbGlobal.Name = "rbGlobal";
            this.rbGlobal.Size = new System.Drawing.Size(69, 22);
            this.rbGlobal.TabIndex = 0;
            this.rbGlobal.TabStop = true;
            this.rbGlobal.Text = "Global";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(870, 28);
            this.panel2.TabIndex = 3;
            this.panel2.TabStop = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("default, Arial Black", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(2, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Pre-member Data Entry";
            // 
            // UCExistingMember
            // 
            this.Controls.Add(this.PExistingMembers);
            this.Name = "UCExistingMember";
            this.Size = new System.Drawing.Size(909, 600);
            this.PExistingMembers.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel PExistingMembers;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label1;
        private Wisej.Web.Button btnExistingMembers;
        private Wisej.Web.Button btnCreateFirstTimerOrNewConvert;
        private Wisej.Web.Button btnFirstTimeNewConvert;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Button btnViewMembers;
        private Wisej.Web.TextBox txtViewMembers;
        private Wisej.Web.ComboBox cbSearchCriteri;
        private Wisej.Web.Label label2;
        private Wisej.Web.RadioButton rbDepartmemt;
        private Wisej.Web.RadioButton rbMemberType;
        private Wisej.Web.RadioButton rbGlobal;
        private Wisej.Web.TextBox txtSearchCriteria;
    }
}
