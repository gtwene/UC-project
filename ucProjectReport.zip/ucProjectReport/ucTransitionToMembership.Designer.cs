﻿namespace UCProject
{
    partial class ucTransitionToMembership
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.btnPreMemberToMember = new Wisej.Web.Button();
            this.panel2 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.btnCreateFirstTimerOrNewConvert = new Wisej.Web.Button();
            this.panel3 = new Wisej.Web.Panel();
            this.panel4 = new Wisej.Web.Panel();
            this.btnGetPreMember = new Wisej.Web.Button();
            this.label2 = new Wisej.Web.Label();
            this.txtEnterPreMemberName = new Wisej.Web.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.btnPreMemberToMember);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.btnCreateFirstTimerOrNewConvert);
            this.panel1.Location = new System.Drawing.Point(22, 19);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(738, 442);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // btnPreMemberToMember
            // 
            this.btnPreMemberToMember.BackColor = System.Drawing.Color.Gainsboro;
            this.btnPreMemberToMember.ForeColor = System.Drawing.Color.Black;
            this.btnPreMemberToMember.Location = new System.Drawing.Point(202, 30);
            this.btnPreMemberToMember.Name = "btnPreMemberToMember";
            this.btnPreMemberToMember.Size = new System.Drawing.Size(200, 27);
            this.btnPreMemberToMember.TabIndex = 12;
            this.btnPreMemberToMember.Text = "Pre-Member To Member";
            this.btnPreMemberToMember.Click += new System.EventHandler(this.btnPreMemberToMember_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(736, 28);
            this.panel2.TabIndex = 4;
            this.panel2.TabStop = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("default, Arial Black", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(227, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Pre-members To Member :";
            // 
            // btnCreateFirstTimerOrNewConvert
            // 
            this.btnCreateFirstTimerOrNewConvert.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCreateFirstTimerOrNewConvert.ForeColor = System.Drawing.Color.Black;
            this.btnCreateFirstTimerOrNewConvert.Location = new System.Drawing.Point(1, 30);
            this.btnCreateFirstTimerOrNewConvert.Name = "btnCreateFirstTimerOrNewConvert";
            this.btnCreateFirstTimerOrNewConvert.Size = new System.Drawing.Size(200, 27);
            this.btnCreateFirstTimerOrNewConvert.TabIndex = 11;
            this.btnCreateFirstTimerOrNewConvert.Text = "Pre-Member Search";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.btnGetPreMember);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.txtEnterPreMemberName);
            this.panel3.Location = new System.Drawing.Point(25, 79);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(731, 428);
            this.panel3.TabIndex = 5;
            this.panel3.TabStop = true;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel4.HeaderForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(6, 90);
            this.panel4.Name = "panel4";
            this.panel4.ShowCloseButton = false;
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(720, 307);
            this.panel4.TabIndex = 9;
            this.panel4.TabStop = true;
            this.panel4.Text = "Search Results";
            // 
            // btnGetPreMember
            // 
            this.btnGetPreMember.BackColor = System.Drawing.Color.Gainsboro;
            this.btnGetPreMember.ForeColor = System.Drawing.Color.Black;
            this.btnGetPreMember.ImageSource = "icon-search";
            this.btnGetPreMember.Location = new System.Drawing.Point(274, 18);
            this.btnGetPreMember.Name = "btnGetPreMember";
            this.btnGetPreMember.Size = new System.Drawing.Size(190, 54);
            this.btnGetPreMember.TabIndex = 8;
            this.btnGetPreMember.Text = "Get Pre-Member";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Enter Pre-Member Name";
            // 
            // txtEnterPreMemberName
            // 
            this.txtEnterPreMemberName.Location = new System.Drawing.Point(15, 50);
            this.txtEnterPreMemberName.Name = "txtEnterPreMemberName";
            this.txtEnterPreMemberName.Size = new System.Drawing.Size(224, 22);
            this.txtEnterPreMemberName.TabIndex = 6;
            // 
            // UCTransitionToMembership
            // 
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "UCTransitionToMembership";
            this.Size = new System.Drawing.Size(778, 480);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Button btnPreMemberToMember;
        private Wisej.Web.Button btnCreateFirstTimerOrNewConvert;
        private Wisej.Web.TextBox txtEnterPreMemberName;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Button btnGetPreMember;
        private Wisej.Web.Label label2;
    }
}
