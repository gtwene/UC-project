﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UCCreateFirstTimerOrNewConvertForm : Wisej.Web.UserControl
    {
        public UCCreateFirstTimerOrNewConvertForm()
        {
            InitializeComponent();
        }










        NewUCShepherdAssignment Shepherd = new NewUCShepherdAssignment();
        private void btnCreateFirstTimerOrNewConvert_Click(object sender, EventArgs e)
        {
            PCreateFirstTimer.Controls.Clear();
            PCreateFirstTimer.Controls.Add(Shepherd);
        }

        private void btnFirstTimeNewConvert_Click(object sender, EventArgs e)
        {

        }

        private void BtnClearAll_Click(object sender, EventArgs e)
        {
            CLEAR_TEXT();
        }
        private void CLEAR_TEXT()
        {
            txtFullName.Text = txtMemberType.Text = txtMobileNo.Text = txtPreMemberRefNo.Text = txtServiceAttended.Text = txtShepherdDepartment.Text = txtShepherdFullName.Text = txtShepherdMemberNo.Text = txtShepherdMemberType.Text = txtShepherdMinistry.Text = txtShepherdMobileNo.Text = txtStatusDecision.Text = "";
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Controls.Clear();
        }

        private void btnAddPreMember_Click(object sender, EventArgs e)
        {
            try
            {
                if (Validate_Controls() == false)
                {
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Add Pre-member ?", GlobalValueCore.ApplicationName, MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {

                    if (CreatePreMember())
                    {

                        GlobalValueCore.InformationMessage("Pre member Added Successfully");
                        //CLEAR_TEXT();
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                    GlobalValueCore.InformationMessage("Cancelled by User");
                }
                //MessageBox.Show(""+branch.checkBranchName(txtBranchName.Text.ToString()));

            }
            catch (Exception ex)
            {
                GlobalValueCore.ExceptionMessage(ex.Message);
            }

        }



        private bool CreatePreMember()
        {
            throw new NotImplementedException();
        }

        private bool Validate_Controls()
        {

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtFullName.Text, "Please Enter Your Full Name. Process Aboretd !"))
            {
                txtFullName.Select();
                return false;
            }



            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtServiceAttended.Text, "Select Service Attended. Process Aboretd !"))
            {
                txtServiceAttended.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtStatusDecision.Text, "Select Status Decision. Process Aboretd !"))
            {
                txtStatusDecision.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtMemberType.Text, "Enter Member Type"))
            {
                txtMemberType.Select();
                return false;
            }
            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtMobileNo.Text, "Enter Mobile No."))
            {
                txtMobileNo.Select();
                return false;
            }
            
            return true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (Validate_Controls() == false) return;
        }



        private void btnAddShepherd_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidateControls() == false)
                {
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Add Pre-member ?", GlobalValueCore.ApplicationName, MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {

                    if (CreateFirstTimerSheherd())
                    {

                        GlobalValueCore.InformationMessage("Pre member Added Successfully");
                        //CLEAR_TEXT();
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                    GlobalValueCore.InformationMessage("Cancelled by User");
                }
                //MessageBox.Show(""+branch.checkBranchName(txtBranchName.Text.ToString()));

            }
            catch (Exception ex)
            {
                GlobalValueCore.ExceptionMessage(ex.Message);
            }

        }



        private bool CreateFirstTimerSheherd()
        {
            throw new NotImplementedException();
        }

        private bool ValidateControls()
        {

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtShepherdFullName.Text, "Please Enter Your Full Name. Process Aboretd !"))
            {
                txtShepherdFullName.Select();
                return false;
            }



            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtShepherdMemberNo.Text, "Select Service Attended. Process Aboretd !"))
            {
                txtShepherdMemberNo.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtShepherdDepartment.Text, "Select Your Department. Process Aboretd !"))
            {
                txtShepherdDepartment.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtShepherdMemberType.Text, "Enter Member Type. Process Aboretd !"))
            {
                txtShepherdMemberType.Select();
                return false;
            }
            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtShepherdMinistry.Text, "What Ministry Do You Belong. Process Aboretd !"))
            {
                txtShepherdMinistry.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(txtShepherdMobileNo.Text, "Enter Mobile No. Process Aboretd !"))
            {
                txtShepherdMobileNo.Select();
                return false;
            }

            return true;
        }
    }
  }


    
    

