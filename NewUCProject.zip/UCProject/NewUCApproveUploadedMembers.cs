﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class NewUCApproveUploadedMembers : Wisej.Web.UserControl
    {
        public NewUCApproveUploadedMembers()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Controls.Clear();
        }

        private void btnApproveAll_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteMembers_Click(object sender, EventArgs e)
        {

        }
    }
}
