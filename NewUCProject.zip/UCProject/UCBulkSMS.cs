﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UCBulkSMS : Wisej.Web.UserControl
    {
        public UCBulkSMS()
        {
            InitializeComponent();
        }

        private void panel4_PanelCollapsed(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            CLEAR_TEXT();
        }

        private void CLEAR_TEXT()
        {
            txtChurch.Text = txtFullName.Text = txtMembershipNo.Text = txtMessage.Text = txtMobileNo.Text = "";
            cbChurch.SelectedIndex = cbDepartment.SelectedIndex = -1;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Controls.Clear();
        }

        private void btnAddtoList_Click(object sender, EventArgs e)
        {

        }

        private void btnSendSMSToMembers_Click(object sender, EventArgs e)
        {

        }
    }
}
