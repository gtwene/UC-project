﻿namespace UCProject
{
    partial class Window1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panChnageable = new Wisej.Web.Panel();
            this.panel2 = new Wisej.Web.Panel();
            this.btnSMS = new Wisej.Web.Button();
            this.button1 = new Wisej.Web.Button();
            this.btnProc = new Wisej.Web.Button();
            this.btnUploadExisting = new Wisej.Web.Button();
            this.btnApproveUploadedMembers = new Wisej.Web.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panChnageable
            // 
            this.panChnageable.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panChnageable.Dock = Wisej.Web.DockStyle.Fill;
            this.panChnageable.Location = new System.Drawing.Point(148, 0);
            this.panChnageable.Name = "panChnageable";
            this.panChnageable.ShowHeader = true;
            this.panChnageable.Size = new System.Drawing.Size(576, 432);
            this.panChnageable.TabIndex = 0;
            this.panChnageable.TabStop = true;
            this.panChnageable.Text = "Chnageable Panel";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.btnApproveUploadedMembers);
            this.panel2.Controls.Add(this.btnUploadExisting);
            this.panel2.Controls.Add(this.btnSMS);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btnProc);
            this.panel2.Dock = Wisej.Web.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(148, 432);
            this.panel2.TabIndex = 1;
            this.panel2.TabStop = true;
            // 
            // btnSMS
            // 
            this.btnSMS.Location = new System.Drawing.Point(32, 107);
            this.btnSMS.Name = "btnSMS";
            this.btnSMS.Size = new System.Drawing.Size(100, 27);
            this.btnSMS.TabIndex = 2;
            this.btnSMS.Text = "SMS";
            this.btnSMS.Click += new System.EventHandler(this.btnSMS_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(32, 63);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 27);
            this.button1.TabIndex = 1;
            this.button1.Text = "UC Pre  Member";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnProc
            // 
            this.btnProc.Location = new System.Drawing.Point(32, 18);
            this.btnProc.Name = "btnProc";
            this.btnProc.Size = new System.Drawing.Size(100, 27);
            this.btnProc.TabIndex = 0;
            this.btnProc.Text = "uc Pro";
            this.btnProc.Click += new System.EventHandler(this.btnProc_Click);
            // 
            // btnUploadExisting
            // 
            this.btnUploadExisting.Location = new System.Drawing.Point(10, 159);
            this.btnUploadExisting.Name = "btnUploadExisting";
            this.btnUploadExisting.Size = new System.Drawing.Size(133, 32);
            this.btnUploadExisting.TabIndex = 3;
            this.btnUploadExisting.Text = "Upload Existing Members";
            this.btnUploadExisting.Click += new System.EventHandler(this.btnUploadExisting_Click);
            // 
            // btnApproveUploadedMembers
            // 
            this.btnApproveUploadedMembers.Location = new System.Drawing.Point(10, 222);
            this.btnApproveUploadedMembers.Name = "btnApproveUploadedMembers";
            this.btnApproveUploadedMembers.Size = new System.Drawing.Size(132, 37);
            this.btnApproveUploadedMembers.TabIndex = 4;
            this.btnApproveUploadedMembers.Text = "Approve Uploaded Members";
            this.btnApproveUploadedMembers.Click += new System.EventHandler(this.btnApproveUploadedMembers_Click);
            // 
            // Window1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 432);
            this.Controls.Add(this.panChnageable);
            this.Controls.Add(this.panel2);
            this.Name = "Window1";
            this.Text = "Form1";
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panChnageable;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Button btnProc;
        private Wisej.Web.Button button1;
        private Wisej.Web.Button btnSMS;
        private Wisej.Web.Button btnApproveUploadedMembers;
        private Wisej.Web.Button btnUploadExisting;
    }
}

