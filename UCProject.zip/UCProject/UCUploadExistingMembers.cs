﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UCUploadExistingMembers : Wisej.Web.UserControl
    {
        public UCUploadExistingMembers()
        {
            InitializeComponent();
        }
    }
}
