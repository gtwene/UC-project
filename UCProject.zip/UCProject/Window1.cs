﻿
using System;
using Wisej.Web;

namespace UCProject
{
    public partial class Window1 : Form
    {
        public Window1()
        {
            InitializeComponent();
        }
        //Instantiate all ur controlsat the top here
        ucPro form1 = new ucPro();//ths line is the same as //Dim from1 as New ucPro
        private void btnProc_Click(object sender, EventArgs e)
        {
            //i will now call the form throught this event
            //u need 2 lne to call ur user control
            //1. Clear changeable panel
            panChnageable.Controls.Clear();
            //2.Add  new control to panel
            panChnageable.Controls.Add(form1);//tas all,please run it again

        }

        UCPreMember form2 = new UCPreMember();
        private void button1_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form2);
        }

        UCBulkSMS form3 = new UCBulkSMS();
        private void btnSMS_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form3);
        }

        UCUploadExistingMembers form4 = new UCUploadExistingMembers();
        private void btnUploadExisting_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form4);
        }

        UCApproveUploadedMembers form5 = new UCApproveUploadedMembers();
        private void btnApproveUploadedMembers_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form5);
        }
    }
}
