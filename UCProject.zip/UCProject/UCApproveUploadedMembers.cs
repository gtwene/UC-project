﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UCApproveUploadedMembers : Wisej.Web.UserControl
    {
        public UCApproveUploadedMembers()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Controls.Clear();
        }
    }
}
