﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UCChurchAttendanceReport : Wisej.Web.UserControl
    {
        public UCChurchAttendanceReport()
        {
            InitializeComponent();
        }
    }
}
