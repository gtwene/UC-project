﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UCMembersAnniversaryPeriodReport : Wisej.Web.UserControl
    {
        public UCMembersAnniversaryPeriodReport()
        {
            InitializeComponent();
        }
    }
}
