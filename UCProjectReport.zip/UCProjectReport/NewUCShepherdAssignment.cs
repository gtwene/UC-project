﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class NewUCShepherdAssignment : Wisej.Web.UserControl
    {
        public NewUCShepherdAssignment()
        {
            InitializeComponent();
        }

        
        private void btnCreateFirstTimerOrNewConvert_Click(object sender, EventArgs e)
        {
          
        }


    }
}
