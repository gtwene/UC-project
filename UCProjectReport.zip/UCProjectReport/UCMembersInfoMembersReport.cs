﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UCMembersInfoMembersReport : Wisej.Web.UserControl
    {
        public UCMembersInfoMembersReport()
        {
            InitializeComponent();
        }
    }
}
