﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucPro : Wisej.Web.UserControl
    {
        public ucPro()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void toolBar1_ButtonClick(object sender, ToolBarButtonClickEventArgs e)
        {

        }

        private void toolBarButton1_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelTransaction_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnClearScreen_Click(object sender, EventArgs e)
        {
            CLEAR_TEXT();
        }

        private void CLEAR_TEXT()
        {
            txtTransAccount.Text = txtTitheRefNo.Text = txtTitheNo.Text = txtAccountNo.Text = txtMemberName.Text = txtGetTithe.Text = txtMinistry.Text = "";
            cbIncomeType.SelectedIndex = cbPaymentMonth.SelectedIndex = cbPaymentYear.SelectedIndex = cbService.SelectedIndex = -1;
        }

    }
}
