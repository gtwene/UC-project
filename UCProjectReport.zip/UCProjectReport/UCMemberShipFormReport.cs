﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UCMemberShipFormReport : Wisej.Web.UserControl
    {
        public UCMemberShipFormReport()
        {
            InitializeComponent();
        }
    }
}
