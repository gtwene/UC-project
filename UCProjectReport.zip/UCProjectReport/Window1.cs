﻿
using System;
using Wisej.Web;

namespace UCProject
{
    public partial class Window1 : Form
    {
        public Window1()
        {
            InitializeComponent();
        }
        //Instantiate all ur controlsat the top here
        ucPro form1 = new ucPro();//ths line is the same as //Dim from1 as New ucPro
        private void btnProc_Click(object sender, EventArgs e)
        {
            //i will now call the form throught this event
            //u need 2 lne to call ur user control
            //1. Clear changeable panel
            panChnageable.Controls.Clear();
            //2.Add  new control to panel
            panChnageable.Controls.Add(form1);//tas all,please run it again

        }

        UCPreMember form2 = new UCPreMember();
        private void button1_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form2);
        }

        UCBulkSMS form3 = new UCBulkSMS();
        private void btnSMS_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form3);
        }

        NewUCUploadExistingMembers form4 = new NewUCUploadExistingMembers();
        private void btnUploadExisting_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form4);
        }

        NewUCApproveUploadedMembers form5 = new NewUCApproveUploadedMembers();
        private void btnApproveUploadedMembers_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form5);
        }

        NewUCPrememberManagerChuchAttendance form6 = new NewUCPrememberManagerChuchAttendance();
        private void button2_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form6);
        }

        NewUCShepherdAssignment form7 = new NewUCShepherdAssignment();
        private void button3_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form7);
        }

        NewUCExistingMember form8 = new NewUCExistingMember();
        private void button4_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form8);
        }

        NewUCTransitionToMembership form9 = new NewUCTransitionToMembership();
        private void button5_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form9);
        }

        NewUCPreMemberToMember form10 = new NewUCPreMemberToMember();
        private void button6_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form10);
        }

        NewUCTransitionToMembershipBatch form11 = new NewUCTransitionToMembershipBatch();
        private void button7_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form11);
        }

        UCCreateFirstTimerOrNewConvertForm form12 = new UCCreateFirstTimerOrNewConvertForm();
        private void button8_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form12);
        }

        UCMembersInfoMembersReport form13 = new UCMembersInfoMembersReport();
        private void button9_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form13);
        }

        UCMembersAnniversaryPeriodReport form14 = new UCMembersAnniversaryPeriodReport();
        private void button10_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form14);
        }

        UCChurchAttendanceReport form15 = new UCChurchAttendanceReport();
        private void button11_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form15);
        }

        UCMemberActivitiesReport form16 = new UCMemberActivitiesReport();
        private void button12_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form16);
        }

        UCMemberShipFormReport form17 = new UCMemberShipFormReport();
        private void button13_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form17);
        }
    }
}
