﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class NewUCExistingMember : Wisej.Web.UserControl
    {
        public NewUCExistingMember()
        {
            InitializeComponent();
        }

        UCCreateFirstTimerOrNewConvertForm Existing = new UCCreateFirstTimerOrNewConvertForm();
        private void btnExistingMembers_Click(object sender, EventArgs e)
        {
            PExistingMembers.Controls.Clear();
            PExistingMembers.Controls.Add(Existing);
        }

        private void btnFirstTimeNewConvert_Click(object sender, EventArgs e)
        {

        }

        //UCExistingMember CreateFirstTimer = new UCExistingMember();
        private void btnCreateFirstTimerOrNewConvert_Click(object sender, EventArgs e)
        {
            
        }
    }
}
