﻿namespace UCProject
{
    partial class Window1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panChnageable = new Wisej.Web.Panel();
            this.button5 = new Wisej.Web.Button();
            this.panel2 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.button13 = new Wisej.Web.Button();
            this.button12 = new Wisej.Web.Button();
            this.button11 = new Wisej.Web.Button();
            this.button10 = new Wisej.Web.Button();
            this.button9 = new Wisej.Web.Button();
            this.button8 = new Wisej.Web.Button();
            this.button7 = new Wisej.Web.Button();
            this.button4 = new Wisej.Web.Button();
            this.button6 = new Wisej.Web.Button();
            this.button3 = new Wisej.Web.Button();
            this.button2 = new Wisej.Web.Button();
            this.btnApproveUploadedMembers = new Wisej.Web.Button();
            this.btnUploadExisting = new Wisej.Web.Button();
            this.btnSMS = new Wisej.Web.Button();
            this.button1 = new Wisej.Web.Button();
            this.btnProc = new Wisej.Web.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panChnageable
            // 
            this.panChnageable.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panChnageable.Dock = Wisej.Web.DockStyle.Fill;
            this.panChnageable.Location = new System.Drawing.Point(258, 0);
            this.panChnageable.Name = "panChnageable";
            this.panChnageable.ShowHeader = true;
            this.panChnageable.Size = new System.Drawing.Size(834, 472);
            this.panChnageable.TabIndex = 0;
            this.panChnageable.TabStop = true;
            this.panChnageable.Text = "Chnageable Panel";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(117, 117);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(67, 31);
            this.button5.TabIndex = 8;
            this.button5.Text = "Transition To Membership";
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.button8);
            this.panel2.Controls.Add(this.button11);
            this.panel2.Controls.Add(this.button13);
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.button9);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button12);
            this.panel2.Controls.Add(this.button6);
            this.panel2.Controls.Add(this.button10);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.btnApproveUploadedMembers);
            this.panel2.Controls.Add(this.btnUploadExisting);
            this.panel2.Controls.Add(this.btnSMS);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.btnProc);
            this.panel2.Dock = Wisej.Web.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(258, 472);
            this.panel2.TabIndex = 1;
            this.panel2.TabStop = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(102, 209);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 15);
            this.label1.TabIndex = 17;
            this.label1.Text = "New";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(73, 397);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(100, 35);
            this.button13.TabIndex = 16;
            this.button13.Text = "Membership Form Report";
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Anchor = Wisej.Web.AnchorStyles.Left;
            this.button12.Location = new System.Drawing.Point(148, 336);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(100, 35);
            this.button12.TabIndex = 15;
            this.button12.Text = "Memberss Activity Report";
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(-1, 320);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(100, 51);
            this.button11.TabIndex = 14;
            this.button11.Text = "Membersship Anniversary Report";
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(148, 249);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(100, 65);
            this.button10.TabIndex = 13;
            this.button10.Text = "Membersship Anniversary Report";
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Anchor = Wisej.Web.AnchorStyles.Left;
            this.button9.Location = new System.Drawing.Point(42, 230);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(100, 65);
            this.button9.TabIndex = 12;
            this.button9.Text = "Members Information / Members Report";
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(201, 52);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(56, 52);
            this.button8.TabIndex = 11;
            this.button8.Text = "UCCreateFirstTimerOrNewConvertForm";
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(192, 106);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(56, 52);
            this.button7.TabIndex = 10;
            this.button7.Text = "Transition TO Membership Batch";
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(117, 84);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(67, 27);
            this.button4.TabIndex = 7;
            this.button4.Text = "Existing Member ";
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(192, 11);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(67, 35);
            this.button6.TabIndex = 9;
            this.button6.Text = "PreMember TO Member";
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(117, 51);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(67, 27);
            this.button3.TabIndex = 6;
            this.button3.Text = "Shepherp Assignment";
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(117, 11);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(67, 34);
            this.button2.TabIndex = 5;
            this.button2.Text = "Premember Manager Attendance";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnApproveUploadedMembers
            // 
            this.btnApproveUploadedMembers.Location = new System.Drawing.Point(10, 153);
            this.btnApproveUploadedMembers.Name = "btnApproveUploadedMembers";
            this.btnApproveUploadedMembers.Size = new System.Drawing.Size(67, 37);
            this.btnApproveUploadedMembers.TabIndex = 4;
            this.btnApproveUploadedMembers.Text = "Approve Uploaded Members";
            this.btnApproveUploadedMembers.Click += new System.EventHandler(this.btnApproveUploadedMembers_Click);
            // 
            // btnUploadExisting
            // 
            this.btnUploadExisting.Location = new System.Drawing.Point(10, 115);
            this.btnUploadExisting.Name = "btnUploadExisting";
            this.btnUploadExisting.Size = new System.Drawing.Size(67, 32);
            this.btnUploadExisting.TabIndex = 3;
            this.btnUploadExisting.Text = "Upload Existing Members";
            this.btnUploadExisting.Click += new System.EventHandler(this.btnUploadExisting_Click);
            // 
            // btnSMS
            // 
            this.btnSMS.Location = new System.Drawing.Point(10, 84);
            this.btnSMS.Name = "btnSMS";
            this.btnSMS.Size = new System.Drawing.Size(45, 27);
            this.btnSMS.TabIndex = 2;
            this.btnSMS.Text = "SMS";
            this.btnSMS.Click += new System.EventHandler(this.btnSMS_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(10, 51);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 27);
            this.button1.TabIndex = 1;
            this.button1.Text = "UC Pre  Member";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnProc
            // 
            this.btnProc.Location = new System.Drawing.Point(10, 18);
            this.btnProc.Name = "btnProc";
            this.btnProc.Size = new System.Drawing.Size(56, 27);
            this.btnProc.TabIndex = 0;
            this.btnProc.Text = "uc Pro";
            this.btnProc.Click += new System.EventHandler(this.btnProc_Click);
            // 
            // Window1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = Wisej.Web.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 472);
            this.Controls.Add(this.panChnageable);
            this.Controls.Add(this.panel2);
            this.Name = "Window1";
            this.Text = "Form1";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panChnageable;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Button btnProc;
        private Wisej.Web.Button button1;
        private Wisej.Web.Button btnSMS;
        private Wisej.Web.Button btnApproveUploadedMembers;
        private Wisej.Web.Button btnUploadExisting;
        private Wisej.Web.Button button2;
        private Wisej.Web.Button button3;
        private Wisej.Web.Button button4;
        private Wisej.Web.Button button5;
        private Wisej.Web.Button button6;
        private Wisej.Web.Button button7;
        private Wisej.Web.Button button8;
        private Wisej.Web.Button button9;
        private Wisej.Web.Button button10;
        private Wisej.Web.Button button11;
        private Wisej.Web.Button button12;
        private Wisej.Web.Button button13;
        private Wisej.Web.Label label1;
    }
}

