﻿namespace UCProject
{
    partial class NewUCTransitionToMembershipBatch
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.toolBar1 = new Wisej.Web.ToolBar();
            this.btnAddMemberBatch = new Wisej.Web.ToolBarButton();
            this.btnCancel = new Wisej.Web.ToolBarButton();
            this.panel2 = new Wisej.Web.Panel();
            this.panel3 = new Wisej.Web.Panel();
            this.panel4 = new Wisej.Web.Panel();
            this.chbCheckAllMembers = new Wisej.Web.CheckBox();
            this.label3 = new Wisej.Web.Label();
            this.cbCreateSelectedPremember = new Wisej.Web.ComboBox();
            this.btnGetPreMember = new Wisej.Web.Button();
            this.txtEnterPreMemberName = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.toolBar1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.btnGetPreMember);
            this.panel1.Controls.Add(this.txtEnterPreMemberName);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = Wisej.Web.DockStyle.Fill;
            this.panel1.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel1.HeaderForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.ShowHeader = true;
            this.panel1.Size = new System.Drawing.Size(864, 481);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            this.panel1.Text = "Search For Pre-Member";
            this.panel1.PanelCollapsed += new System.EventHandler(this.panel1_PanelCollapsed);
            // 
            // toolBar1
            // 
            this.toolBar1.AutoSize = false;
            this.toolBar1.BackColor = System.Drawing.Color.PowderBlue;
            this.toolBar1.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnAddMemberBatch,
            this.btnCancel});
            this.toolBar1.Dock = Wisej.Web.DockStyle.Bottom;
            this.toolBar1.Location = new System.Drawing.Point(0, 403);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(862, 48);
            this.toolBar1.TabIndex = 5;
            this.toolBar1.TabStop = false;
            // 
            // btnAddMemberBatch
            // 
            this.btnAddMemberBatch.ImageSource = "spinner-plus";
            this.btnAddMemberBatch.Name = "btnAddMemberBatch";
            this.btnAddMemberBatch.Text = "Add Member-Batch";
            this.btnAddMemberBatch.Click += new System.EventHandler(this.btnAddMemberBatch_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.ImageSource = "icon-close";
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel2.HeaderForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(3, 87);
            this.panel2.Name = "panel2";
            this.panel2.ShowCloseButton = false;
            this.panel2.ShowHeader = true;
            this.panel2.Size = new System.Drawing.Size(856, 310);
            this.panel2.TabIndex = 3;
            this.panel2.TabStop = true;
            this.panel2.Text = "Search Results";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(848, 274);
            this.panel3.TabIndex = 0;
            this.panel3.TabStop = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightCyan;
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.chbCheckAllMembers);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.cbCreateSelectedPremember);
            this.panel4.Dock = Wisej.Web.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(846, 47);
            this.panel4.TabIndex = 1;
            this.panel4.TabStop = true;
            // 
            // chbCheckAllMembers
            // 
            this.chbCheckAllMembers.Location = new System.Drawing.Point(25, 11);
            this.chbCheckAllMembers.Name = "chbCheckAllMembers";
            this.chbCheckAllMembers.Size = new System.Drawing.Size(144, 22);
            this.chbCheckAllMembers.TabIndex = 8;
            this.chbCheckAllMembers.Text = "Check All Members";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(188, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(273, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "Create Selected Pre-Members As Members Of";
            // 
            // cbCreateSelectedPremember
            // 
            this.cbCreateSelectedPremember.Location = new System.Drawing.Point(477, 10);
            this.cbCreateSelectedPremember.Name = "cbCreateSelectedPremember";
            this.cbCreateSelectedPremember.Size = new System.Drawing.Size(329, 22);
            this.cbCreateSelectedPremember.TabIndex = 0;
            // 
            // btnGetPreMember
            // 
            this.btnGetPreMember.BackColor = System.Drawing.Color.Gainsboro;
            this.btnGetPreMember.ForeColor = System.Drawing.Color.Black;
            this.btnGetPreMember.ImageSource = "icon-search";
            this.btnGetPreMember.Location = new System.Drawing.Point(349, 40);
            this.btnGetPreMember.Name = "btnGetPreMember";
            this.btnGetPreMember.Size = new System.Drawing.Size(201, 27);
            this.btnGetPreMember.TabIndex = 2;
            this.btnGetPreMember.Text = "Get Pre-Member";
            // 
            // txtEnterPreMemberName
            // 
            this.txtEnterPreMemberName.Location = new System.Drawing.Point(25, 45);
            this.txtEnterPreMemberName.Name = "txtEnterPreMemberName";
            this.txtEnterPreMemberName.Size = new System.Drawing.Size(269, 22);
            this.txtEnterPreMemberName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Pre-Member Name";
            // 
            // NewUCTransitionToMembershipBatch
            // 
            this.Controls.Add(this.panel1);
            this.Name = "NewUCTransitionToMembershipBatch";
            this.Size = new System.Drawing.Size(864, 481);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.ToolBar toolBar1;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.ComboBox cbCreateSelectedPremember;
        private Wisej.Web.Button btnGetPreMember;
        private Wisej.Web.TextBox txtEnterPreMemberName;
        private Wisej.Web.Label label1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.CheckBox chbCheckAllMembers;
        private Wisej.Web.Label label3;
        private Wisej.Web.ToolBarButton btnAddMemberBatch;
        private Wisej.Web.ToolBarButton btnCancel;
    }
}
