﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class NewUCUploadExistingMembers : Wisej.Web.UserControl
    {
        public NewUCUploadExistingMembers()
        {
            InitializeComponent();
        }

        private void btnUploadData_Click(object sender, EventArgs e)
        {

        }
    }
}
