﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UCMemberActivitiesReport : Wisej.Web.UserControl
    {
        public UCMemberActivitiesReport()
        {
            InitializeComponent();
        }
    }
}
