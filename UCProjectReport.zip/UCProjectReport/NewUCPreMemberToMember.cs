﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class NewUCPreMemberToMember : Wisej.Web.UserControl
    {
        public NewUCPreMemberToMember()
        {
            InitializeComponent();
        }

        private void panel2_PanelCollapsed(object sender, EventArgs e)
        {

        }

        private void panel3_PanelCollapsed(object sender, EventArgs e)
        {

        }

        private void panel1_PanelCollapsed(object sender, EventArgs e)
        {

        }

        private void btnAddNewChuchMember_Click(object sender, EventArgs e)
        {
            try
            {
                if (Validate_Controls() == false)
                {
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Create Pre-member ?", GlobalValueCore.ApplicationName, MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {

                    if (CreatePreMember())
                    {

                        GlobalValueCore.InformationMessage("Pre member Created Successfully");
                        //CLEAR_TEXT();
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                    GlobalValueCore.InformationMessage("Cancelled by User");
                }
                //MessageBox.Show(""+branch.checkBranchName(txtBranchName.Text.ToString()));

            }
            catch (Exception ex)
            {
                GlobalValueCore.ExceptionMessage(ex.Message);
            }

        }



        private bool CreatePreMember()
        {
            throw new NotImplementedException();
        }

        private bool Validate_Controls()
        {
           
           
            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtAnyCommentOnMembershipLesson.Text, "Please Enter Comment On Membership Lesson. Process Aboretd !"))
            {
                txtAnyCommentOnMembershipLesson.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtAnyCommentOnBaptism.Text, "Please Enter Comments On Baptism. Process Aboretd !"))
            {
                txtAnyCommentOnBaptism.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtPreMemberType.Text, "Please Enter Member Type"))
            {
                txtPreMemberType.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtPreMemberRefNo.Text, "Please Enter Your Reference Number"))
            {
                txtPreMemberRefNo.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtSurname.Text, "Please Enter Your Surname"))
            {
                txtSurname.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtOtherName.Text, "Please Enter Your Other Name?"))
            {
                txtOtherName.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbGender, cbGender.Text, "Please Gender"))
            {
                cbGender.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbYearJoined, cbYearJoined.Text, ""))
            {
                cbYearJoined.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtNationality.Text, "Please your Nationality ?"))
            {
                txtNationality.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtMobileNo.Text, "Please Enter Your Mobile No"))
            {
                txtMobileNo.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtTelephone.Text, "Please Enter Telephone Number"))
            {
                txtTelephone.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtEmail.Text, "Enter Your Email."))
            {
                txtEmail.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbMaritalStatus, cbMaritalStatus.Text, "Your Marital Status"))
            {
                cbMaritalStatus.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtResidentialAddress.Text, "Please Enter Your Residential Address"))
            {
                txtResidentialAddress.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbChurchMinistry, cbChurchMinistry.Text, "Please What's Your ministry"))
            {
                cbChurchMinistry.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbInADepartment, cbInADepartment.Text, "Please Hope You are In a Department ?"))
            {
                cbInADepartment.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbDepartmemt, cbDepartmemt.Text, "Your Department"))
            {
                cbDepartmemt.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbWelfare, cbWelfare.Text, ""))
            {
                cbWelfare.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtTitheNo.Text, " Please Enter Tithe Number"))
            {
                txtTitheNo.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbAreaClassification, cbAreaClassification.Text, "Please Classification"))
            {
                cbAreaClassification.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbNameOfCell, cbNameOfCell.Text, ""))
            {
                cbNameOfCell.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbInHomeCell, cbInHomeCell.Text, "Enter Your Home Cell"))
            {
                cbInHomeCell.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbEmploymentStatus, cbEmploymentStatus.Text, "Please What's Your Employment Status"))
            {
                cbEmploymentStatus.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtNameOfEmployer.Text, "Please Enter The Employer's Name"))
            {
                txtNameOfEmployer.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtOccupation.Text, "Please What Work Do you Do ?"))
            {
                txtOccupation.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtBusinessAddress.Text, "Enter Business Address. Process Aboretd !"))
            {
                txtBusinessAddress.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtNameOfStudent.Text, "Please Enter Your Name"))
            {
                txtNameOfStudent.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtLevelForm.Text, "Please Enter Your Level Or Form"))
            {
                txtLevelForm.Select();
                return false;

            }




            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtHall.Text, "Enter Your Hall."))
            {
                txtHall.Select();
                return false;
            }
                                             

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtProgramOfStudy.Text, "Please Enter Your Program Of Study"))
            {
                txtProgramOfStudy.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtRoomNo.Text, "Please Enter Your Room Number"))
            {
                txtRoomNo.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbResidentOnCampus, cbResidentOnCampus.Text, "Please Are You Resident On Campus"))
            {
                cbResidentOnCampus.Select();
                return false;
            }




            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbResidentOnCampus, cbResidentOnCampus.Text, "Please Enter your Residence"))
            {
                cbResidentOnCampus.Select();
                return false;
            }

           

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbAcademicLevel, cbAcademicLevel.Text, "Please Enter Your Room Number"))
            {
                cbAcademicLevel.Select();
                return false;
            }

            

           

 

            

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(cbNationality, cbNationality.Text, ""))
            {
                cbNationality.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(cbOccupation,cbOccupation.Text, ""))
            {
                cbOccupation.Select();
                return false;
            }

            
            
            
            //if (cbEmploymentStatus.Text == "Student")
            //{
            //    pResidentialinfo.Show();

            //}else
            //{
            //    pStudentResidentialInfo_PanelCollapsed()
            //}


            return true;
        }

    }
}

