﻿ namespace UCProject
{
    partial class NewUCApproveUploadedMembers
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel3 = new Wisej.Web.Panel();
            this.panel5 = new Wisej.Web.Panel();
            this.txtNoOfNonTithers = new Wisej.Web.TextBox();
            this.txtNoOfRow = new Wisej.Web.TextBox();
            this.txtNoOfTithers = new Wisej.Web.TextBox();
            this.label3 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.btnDeleteMembers = new Wisej.Web.Button();
            this.btnCancel = new Wisej.Web.Button();
            this.btnApproveAll = new Wisej.Web.Button();
            this.panel4 = new Wisej.Web.Panel();
            this.btnViewPending = new Wisej.Web.Button();
            this.panel2 = new Wisej.Web.Panel();
            this.label4 = new Wisej.Web.Label();
            this.btnExcelRecordUpload = new Wisej.Web.Button();
            this.btnMobileRecordUpload = new Wisej.Web.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, 61);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(936, 421);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(602, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(314, 434);
            this.panel3.TabIndex = 1;
            this.panel3.TabStop = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.txtNoOfNonTithers);
            this.panel5.Controls.Add(this.txtNoOfRow);
            this.panel5.Controls.Add(this.txtNoOfTithers);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.btnDeleteMembers);
            this.panel5.Controls.Add(this.btnCancel);
            this.panel5.Controls.Add(this.btnApproveAll);
            this.panel5.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel5.HeaderForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(11, 78);
            this.panel5.Name = "panel5";
            this.panel5.ShowCloseButton = false;
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(289, 338);
            this.panel5.TabIndex = 1;
            this.panel5.TabStop = true;
            this.panel5.Text = "Data Statistics";
            // 
            // txtNoOfNonTithers
            // 
            this.txtNoOfNonTithers.Location = new System.Drawing.Point(128, 42);
            this.txtNoOfNonTithers.Name = "txtNoOfNonTithers";
            this.txtNoOfNonTithers.Size = new System.Drawing.Size(150, 22);
            this.txtNoOfNonTithers.TabIndex = 8;
            // 
            // txtNoOfRow
            // 
            this.txtNoOfRow.Location = new System.Drawing.Point(128, 73);
            this.txtNoOfRow.Name = "txtNoOfRow";
            this.txtNoOfRow.Size = new System.Drawing.Size(150, 22);
            this.txtNoOfRow.TabIndex = 7;
            // 
            // txtNoOfTithers
            // 
            this.txtNoOfTithers.Location = new System.Drawing.Point(128, 10);
            this.txtNoOfTithers.Name = "txtNoOfTithers";
            this.txtNoOfTithers.Size = new System.Drawing.Size(150, 22);
            this.txtNoOfTithers.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "No Of Row";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "No Of Non Tithers";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "No Of Tithers";
            // 
            // btnDeleteMembers
            // 
            this.btnDeleteMembers.BackColor = System.Drawing.Color.Gainsboro;
            this.btnDeleteMembers.ForeColor = System.Drawing.Color.Black;
            this.btnDeleteMembers.Location = new System.Drawing.Point(90, 263);
            this.btnDeleteMembers.Name = "btnDeleteMembers";
            this.btnDeleteMembers.Size = new System.Drawing.Size(105, 27);
            this.btnDeleteMembers.TabIndex = 2;
            this.btnDeleteMembers.Text = "Delete Members";
            this.btnDeleteMembers.Click += new System.EventHandler(this.btnDeleteMembers_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCancel.ForeColor = System.Drawing.Color.Black;
            this.btnCancel.Location = new System.Drawing.Point(204, 263);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(74, 27);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnApproveAll
            // 
            this.btnApproveAll.BackColor = System.Drawing.Color.Gainsboro;
            this.btnApproveAll.ForeColor = System.Drawing.Color.Black;
            this.btnApproveAll.Location = new System.Drawing.Point(9, 263);
            this.btnApproveAll.Name = "btnApproveAll";
            this.btnApproveAll.Size = new System.Drawing.Size(71, 27);
            this.btnApproveAll.TabIndex = 0;
            this.btnApproveAll.Text = "Approve All";
            this.btnApproveAll.Click += new System.EventHandler(this.btnApproveAll_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.btnViewPending);
            this.panel4.Dock = Wisej.Web.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(312, 59);
            this.panel4.TabIndex = 0;
            this.panel4.TabStop = true;
            // 
            // btnViewPending
            // 
            this.btnViewPending.BackColor = System.Drawing.Color.Gainsboro;
            this.btnViewPending.ForeColor = System.Drawing.Color.Black;
            this.btnViewPending.Location = new System.Drawing.Point(61, 17);
            this.btnViewPending.Name = "btnViewPending";
            this.btnViewPending.Size = new System.Drawing.Size(185, 27);
            this.btnViewPending.TabIndex = 0;
            this.btnViewPending.Text = "View Pending";
            this.btnViewPending.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel2.HeaderForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.ShowHeader = true;
            this.panel2.Size = new System.Drawing.Size(593, 434);
            this.panel2.TabIndex = 0;
            this.panel2.TabStop = true;
            this.panel2.Text = "Uploaded Tithers Data";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("default, Arial Black", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(314, 8);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(299, 30);
            this.label4.TabIndex = 9;
            this.label4.Text = "Member Info Upload Authorization";
            // 
            // btnExcelRecordUpload
            // 
            this.btnExcelRecordUpload.BackColor = System.Drawing.Color.Gainsboro;
            this.btnExcelRecordUpload.ForeColor = System.Drawing.Color.Black;
            this.btnExcelRecordUpload.Location = new System.Drawing.Point(3, 32);
            this.btnExcelRecordUpload.Name = "btnExcelRecordUpload";
            this.btnExcelRecordUpload.Size = new System.Drawing.Size(157, 27);
            this.btnExcelRecordUpload.TabIndex = 0;
            this.btnExcelRecordUpload.Text = "Excel Record Upload";
            // 
            // btnMobileRecordUpload
            // 
            this.btnMobileRecordUpload.BackColor = System.Drawing.Color.Gainsboro;
            this.btnMobileRecordUpload.ForeColor = System.Drawing.Color.Black;
            this.btnMobileRecordUpload.Location = new System.Drawing.Point(163, 32);
            this.btnMobileRecordUpload.Name = "btnMobileRecordUpload";
            this.btnMobileRecordUpload.Size = new System.Drawing.Size(157, 27);
            this.btnMobileRecordUpload.TabIndex = 1;
            this.btnMobileRecordUpload.Text = "Mobile record Upload";
            // 
            // NewUCApproveUploadedMembers
            // 
            this.Controls.Add(this.btnExcelRecordUpload);
            this.Controls.Add(this.btnMobileRecordUpload);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.Name = "NewUCApproveUploadedMembers";
            this.Size = new System.Drawing.Size(942, 507);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.TextBox txtNoOfNonTithers;
        private Wisej.Web.TextBox txtNoOfRow;
        private Wisej.Web.TextBox txtNoOfTithers;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label2;
        private Wisej.Web.Label label1;
        private Wisej.Web.Button btnDeleteMembers;
        private Wisej.Web.Button btnCancel;
        private Wisej.Web.Button btnApproveAll;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Button btnViewPending;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label4;
        private Wisej.Web.Button btnExcelRecordUpload;
        private Wisej.Web.Button btnMobileRecordUpload;
    }
}
