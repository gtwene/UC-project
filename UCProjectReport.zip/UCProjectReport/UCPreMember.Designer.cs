﻿namespace UCProject
{
    partial class UCPreMember
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pAttendanceInfo = new Wisej.Web.Panel();
            this.cbServiceAttendance = new Wisej.Web.ComboBox();
            this.cbChurchAttendance = new Wisej.Web.ComboBox();
            this.dtpattendance = new Wisej.Web.DateTimePicker();
            this.label4 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.panel1 = new Wisej.Web.Panel();
            this.pStudentResidentialInfo = new Wisej.Web.Panel();
            this.tbRoomNumber = new Wisej.Web.TextBox();
            this.tbHallOfAffiliation = new Wisej.Web.TextBox();
            this.label26 = new Wisej.Web.Label();
            this.label25 = new Wisej.Web.Label();
            this.cbResidentOnCampus = new Wisej.Web.ComboBox();
            this.label24 = new Wisej.Web.Label();
            this.tbProgramOfStudy = new Wisej.Web.TextBox();
            this.label23 = new Wisej.Web.Label();
            this.label22 = new Wisej.Web.Label();
            this.tblevelform = new Wisej.Web.TextBox();
            this.label21 = new Wisej.Web.Label();
            this.cbAcademic = new Wisej.Web.ComboBox();
            this.tbNameOfSchool = new Wisej.Web.TextBox();
            this.label20 = new Wisej.Web.Label();
            this.pEmploymentDetails = new Wisej.Web.Panel();
            this.tbDesignation = new Wisej.Web.TextBox();
            this.label19 = new Wisej.Web.Label();
            this.label18 = new Wisej.Web.Label();
            this.tbBusinessAddress = new Wisej.Web.TextBox();
            this.tbNameOfEmployer = new Wisej.Web.TextBox();
            this.label17 = new Wisej.Web.Label();
            this.label16 = new Wisej.Web.Label();
            this.cbEmploymentStatus = new Wisej.Web.ComboBox();
            this.pResidentialinfo = new Wisej.Web.Panel();
            this.checkBoxSurburb = new Wisej.Web.CheckBox();
            this.label15 = new Wisej.Web.Label();
            this.label14 = new Wisej.Web.Label();
            this.cbNameOfCell = new Wisej.Web.ComboBox();
            this.cbSurburbArea = new Wisej.Web.ComboBox();
            this.label13 = new Wisej.Web.Label();
            this.tbResidentialAddress = new Wisej.Web.TextBox();
            this.pPersonalInfo = new Wisej.Web.Panel();
            this.label12 = new Wisej.Web.Label();
            this.tbTelephoneNumber = new Wisej.Web.TextBox();
            this.tbMobileNumber = new Wisej.Web.TextBox();
            this.label11 = new Wisej.Web.Label();
            this.tbEmail = new Wisej.Web.TextBox();
            this.label10 = new Wisej.Web.Label();
            this.checkboxUseRealAge = new Wisej.Web.CheckBox();
            this.dtpDOB = new Wisej.Web.DateTimePicker();
            this.label9 = new Wisej.Web.Label();
            this.cbGender = new Wisej.Web.ComboBox();
            this.label8 = new Wisej.Web.Label();
            this.tbOthernames = new Wisej.Web.TextBox();
            this.label7 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.cbMemberType = new Wisej.Web.ComboBox();
            this.tbSurname = new Wisej.Web.TextBox();
            this.label5 = new Wisej.Web.Label();
            this.label1 = new Wisej.Web.Label();
            this.panel6 = new Wisej.Web.Panel();
            this.toolBar1 = new Wisej.Web.ToolBar();
            this.btnSavePreMember = new Wisej.Web.ToolBarButton();
            this.btnClear = new Wisej.Web.ToolBarButton();
            this.btnUpdate = new Wisej.Web.ToolBarButton();
            this.pAttendanceInfo.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pStudentResidentialInfo.SuspendLayout();
            this.pEmploymentDetails.SuspendLayout();
            this.pResidentialinfo.SuspendLayout();
            this.pPersonalInfo.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // pAttendanceInfo
            // 
            this.pAttendanceInfo.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pAttendanceInfo.Controls.Add(this.cbServiceAttendance);
            this.pAttendanceInfo.Controls.Add(this.cbChurchAttendance);
            this.pAttendanceInfo.Controls.Add(this.dtpattendance);
            this.pAttendanceInfo.Controls.Add(this.label4);
            this.pAttendanceInfo.Controls.Add(this.label3);
            this.pAttendanceInfo.Controls.Add(this.label2);
            this.pAttendanceInfo.Dock = Wisej.Web.DockStyle.Top;
            this.pAttendanceInfo.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.pAttendanceInfo.HeaderForeColor = System.Drawing.Color.Black;
            this.pAttendanceInfo.Location = new System.Drawing.Point(0, 0);
            this.pAttendanceInfo.Name = "pAttendanceInfo";
            this.pAttendanceInfo.ShowHeader = true;
            this.pAttendanceInfo.Size = new System.Drawing.Size(926, 114);
            this.pAttendanceInfo.TabIndex = 0;
            this.pAttendanceInfo.TabStop = true;
            this.pAttendanceInfo.Text = "Attendance Information";
            // 
            // cbServiceAttendance
            // 
            this.cbServiceAttendance.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbServiceAttendance.Items.AddRange(new object[] {
            "Sunday - First Service",
            "Sunday - Second Service",
            "Perez Hour",
            "All-Night Service",
            "Crusade",
            "Sunday - Third Service",
            "Tuesday Breakthrough Service",
            "Extended Prayer Meeting"});
            this.cbServiceAttendance.LabelText = "";
            this.cbServiceAttendance.Location = new System.Drawing.Point(604, 38);
            this.cbServiceAttendance.Name = "cbServiceAttendance";
            this.cbServiceAttendance.Size = new System.Drawing.Size(261, 22);
            this.cbServiceAttendance.TabIndex = 6;
            // 
            // cbChurchAttendance
            // 
            this.cbChurchAttendance.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbChurchAttendance.Items.AddRange(new object[] {
            "Adults Service - Perez Dome",
            "French Service",
            "Timothy Generation Service",
            "Twi Service"});
            this.cbChurchAttendance.LabelText = "";
            this.cbChurchAttendance.Location = new System.Drawing.Point(297, 38);
            this.cbChurchAttendance.Name = "cbChurchAttendance";
            this.cbChurchAttendance.Size = new System.Drawing.Size(261, 22);
            this.cbChurchAttendance.TabIndex = 2;
            this.cbChurchAttendance.SelectedIndexChanged += new System.EventHandler(this.cbChurchAttendance_SelectedIndexChanged);
            // 
            // dtpattendance
            // 
            this.dtpattendance.Checked = false;
            this.dtpattendance.LabelText = "";
            this.dtpattendance.Location = new System.Drawing.Point(12, 36);
            this.dtpattendance.Name = "dtpattendance";
            this.dtpattendance.Size = new System.Drawing.Size(247, 22);
            this.dtpattendance.TabIndex = 1;
            this.dtpattendance.Value = new System.DateTime(2020, 9, 4, 11, 6, 40, 118);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(604, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Service Attended";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(297, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Church Attended";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(12, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Date Of Attendance";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.pStudentResidentialInfo);
            this.panel1.Controls.Add(this.pEmploymentDetails);
            this.panel1.Controls.Add(this.pResidentialinfo);
            this.panel1.Controls.Add(this.pPersonalInfo);
            this.panel1.Controls.Add(this.pAttendanceInfo);
            this.panel1.Location = new System.Drawing.Point(3, 37);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(945, 413);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // pStudentResidentialInfo
            // 
            this.pStudentResidentialInfo.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pStudentResidentialInfo.Controls.Add(this.tbRoomNumber);
            this.pStudentResidentialInfo.Controls.Add(this.tbHallOfAffiliation);
            this.pStudentResidentialInfo.Controls.Add(this.label26);
            this.pStudentResidentialInfo.Controls.Add(this.label25);
            this.pStudentResidentialInfo.Controls.Add(this.cbResidentOnCampus);
            this.pStudentResidentialInfo.Controls.Add(this.label24);
            this.pStudentResidentialInfo.Controls.Add(this.tbProgramOfStudy);
            this.pStudentResidentialInfo.Controls.Add(this.label23);
            this.pStudentResidentialInfo.Controls.Add(this.label22);
            this.pStudentResidentialInfo.Controls.Add(this.tblevelform);
            this.pStudentResidentialInfo.Controls.Add(this.label21);
            this.pStudentResidentialInfo.Controls.Add(this.cbAcademic);
            this.pStudentResidentialInfo.Controls.Add(this.tbNameOfSchool);
            this.pStudentResidentialInfo.Controls.Add(this.label20);
            this.pStudentResidentialInfo.Dock = Wisej.Web.DockStyle.Top;
            this.pStudentResidentialInfo.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.pStudentResidentialInfo.HeaderForeColor = System.Drawing.Color.Black;
            this.pStudentResidentialInfo.Location = new System.Drawing.Point(0, 763);
            this.pStudentResidentialInfo.Name = "pStudentResidentialInfo";
            this.pStudentResidentialInfo.ShowHeader = true;
            this.pStudentResidentialInfo.Size = new System.Drawing.Size(926, 199);
            this.pStudentResidentialInfo.TabIndex = 3;
            this.pStudentResidentialInfo.TabStop = true;
            this.pStudentResidentialInfo.Text = "Student Residential Info.";
            this.pStudentResidentialInfo.PanelCollapsed += new System.EventHandler(this.pStudentResidentialInfo_PanelCollapsed);
            // 
            // tbRoomNumber
            // 
            this.tbRoomNumber.LabelText = "";
            this.tbRoomNumber.Location = new System.Drawing.Point(580, 116);
            this.tbRoomNumber.Name = "tbRoomNumber";
            this.tbRoomNumber.Size = new System.Drawing.Size(285, 22);
            this.tbRoomNumber.TabIndex = 42;
            // 
            // tbHallOfAffiliation
            // 
            this.tbHallOfAffiliation.LabelText = "";
            this.tbHallOfAffiliation.Location = new System.Drawing.Point(286, 116);
            this.tbHallOfAffiliation.Name = "tbHallOfAffiliation";
            this.tbHallOfAffiliation.Size = new System.Drawing.Size(261, 22);
            this.tbHallOfAffiliation.TabIndex = 41;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(580, 95);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(88, 15);
            this.label26.TabIndex = 40;
            this.label26.Text = "Room Number";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(286, 95);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(140, 15);
            this.label25.TabIndex = 39;
            this.label25.Text = "If Yes, Hall Of Affiliation";
            // 
            // cbResidentOnCampus
            // 
            this.cbResidentOnCampus.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbResidentOnCampus.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cbResidentOnCampus.LabelText = "";
            this.cbResidentOnCampus.Location = new System.Drawing.Point(12, 116);
            this.cbResidentOnCampus.Name = "cbResidentOnCampus";
            this.cbResidentOnCampus.Size = new System.Drawing.Size(247, 22);
            this.cbResidentOnCampus.TabIndex = 38;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(12, 95);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(189, 15);
            this.label24.TabIndex = 37;
            this.label24.Text = "Are You Resident On Campus ?";
            // 
            // tbProgramOfStudy
            // 
            this.tbProgramOfStudy.LabelText = "";
            this.tbProgramOfStudy.Location = new System.Drawing.Point(579, 34);
            this.tbProgramOfStudy.Name = "tbProgramOfStudy";
            this.tbProgramOfStudy.Size = new System.Drawing.Size(285, 22);
            this.tbProgramOfStudy.TabIndex = 33;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(580, 14);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(108, 15);
            this.label23.TabIndex = 36;
            this.label23.Text = "Program Of Study";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(435, 12);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(69, 15);
            this.label22.TabIndex = 35;
            this.label22.Text = "Level/Form";
            // 
            // tblevelform
            // 
            this.tblevelform.LabelText = "";
            this.tblevelform.Location = new System.Drawing.Point(435, 34);
            this.tblevelform.Name = "tblevelform";
            this.tblevelform.Size = new System.Drawing.Size(112, 22);
            this.tblevelform.TabIndex = 33;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(286, 13);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(95, 15);
            this.label21.TabIndex = 34;
            this.label21.Text = "Academic Level";
            // 
            // cbAcademic
            // 
            this.cbAcademic.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbAcademic.Items.AddRange(new object[] {
            "JHS",
            "SHS",
            "Polytechnic",
            "University",
            "Professional/Vocational School"});
            this.cbAcademic.LabelText = "";
            this.cbAcademic.Location = new System.Drawing.Point(286, 34);
            this.cbAcademic.Name = "cbAcademic";
            this.cbAcademic.Size = new System.Drawing.Size(143, 22);
            this.cbAcademic.TabIndex = 33;
            // 
            // tbNameOfSchool
            // 
            this.tbNameOfSchool.LabelText = "";
            this.tbNameOfSchool.Location = new System.Drawing.Point(12, 35);
            this.tbNameOfSchool.Name = "tbNameOfSchool";
            this.tbNameOfSchool.Size = new System.Drawing.Size(247, 22);
            this.tbNameOfSchool.TabIndex = 33;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(12, 14);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(99, 15);
            this.label20.TabIndex = 33;
            this.label20.Text = "Name Of School";
            // 
            // pEmploymentDetails
            // 
            this.pEmploymentDetails.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pEmploymentDetails.Controls.Add(this.tbDesignation);
            this.pEmploymentDetails.Controls.Add(this.label19);
            this.pEmploymentDetails.Controls.Add(this.label18);
            this.pEmploymentDetails.Controls.Add(this.tbBusinessAddress);
            this.pEmploymentDetails.Controls.Add(this.tbNameOfEmployer);
            this.pEmploymentDetails.Controls.Add(this.label17);
            this.pEmploymentDetails.Controls.Add(this.label16);
            this.pEmploymentDetails.Controls.Add(this.cbEmploymentStatus);
            this.pEmploymentDetails.Dock = Wisej.Web.DockStyle.Top;
            this.pEmploymentDetails.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.pEmploymentDetails.HeaderForeColor = System.Drawing.Color.Black;
            this.pEmploymentDetails.Location = new System.Drawing.Point(0, 529);
            this.pEmploymentDetails.Name = "pEmploymentDetails";
            this.pEmploymentDetails.ShowHeader = true;
            this.pEmploymentDetails.Size = new System.Drawing.Size(926, 234);
            this.pEmploymentDetails.TabIndex = 3;
            this.pEmploymentDetails.TabStop = true;
            this.pEmploymentDetails.Text = "Employment Details";
            // 
            // tbDesignation
            // 
            this.tbDesignation.LabelText = "";
            this.tbDesignation.Location = new System.Drawing.Point(580, 39);
            this.tbDesignation.Name = "tbDesignation";
            this.tbDesignation.Size = new System.Drawing.Size(285, 22);
            this.tbDesignation.TabIndex = 31;
            // 
            // label19
            // 
            this.label19.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(579, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 15);
            this.label19.TabIndex = 32;
            this.label19.Text = "Designation";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(12, 85);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 15);
            this.label18.TabIndex = 30;
            this.label18.Text = "Business Address";
            // 
            // tbBusinessAddress
            // 
            this.tbBusinessAddress.LabelText = "";
            this.tbBusinessAddress.Location = new System.Drawing.Point(12, 106);
            this.tbBusinessAddress.Multiline = true;
            this.tbBusinessAddress.Name = "tbBusinessAddress";
            this.tbBusinessAddress.Size = new System.Drawing.Size(853, 81);
            this.tbBusinessAddress.TabIndex = 29;
            // 
            // tbNameOfEmployer
            // 
            this.tbNameOfEmployer.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.tbNameOfEmployer.LabelText = "";
            this.tbNameOfEmployer.Location = new System.Drawing.Point(286, 39);
            this.tbNameOfEmployer.Name = "tbNameOfEmployer";
            this.tbNameOfEmployer.Size = new System.Drawing.Size(261, 22);
            this.tbNameOfEmployer.TabIndex = 22;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(286, 18);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(114, 15);
            this.label17.TabIndex = 28;
            this.label17.Text = "Name Of Employer";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(12, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(116, 15);
            this.label16.TabIndex = 26;
            this.label16.Text = "Employment Status";
            // 
            // cbEmploymentStatus
            // 
            this.cbEmploymentStatus.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbEmploymentStatus.Items.AddRange(new object[] {
            "Employed",
            "Hired",
            "Self-Employed",
            "Student",
            "Trainee"});
            this.cbEmploymentStatus.LabelText = "";
            this.cbEmploymentStatus.Location = new System.Drawing.Point(12, 38);
            this.cbEmploymentStatus.Name = "cbEmploymentStatus";
            this.cbEmploymentStatus.Size = new System.Drawing.Size(247, 22);
            this.cbEmploymentStatus.TabIndex = 27;
            // 
            // pResidentialinfo
            // 
            this.pResidentialinfo.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pResidentialinfo.Controls.Add(this.checkBoxSurburb);
            this.pResidentialinfo.Controls.Add(this.label15);
            this.pResidentialinfo.Controls.Add(this.label14);
            this.pResidentialinfo.Controls.Add(this.cbNameOfCell);
            this.pResidentialinfo.Controls.Add(this.cbSurburbArea);
            this.pResidentialinfo.Controls.Add(this.label13);
            this.pResidentialinfo.Controls.Add(this.tbResidentialAddress);
            this.pResidentialinfo.Dock = Wisej.Web.DockStyle.Top;
            this.pResidentialinfo.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.pResidentialinfo.HeaderForeColor = System.Drawing.Color.Black;
            this.pResidentialinfo.Location = new System.Drawing.Point(0, 348);
            this.pResidentialinfo.Name = "pResidentialinfo";
            this.pResidentialinfo.ShowHeader = true;
            this.pResidentialinfo.Size = new System.Drawing.Size(926, 181);
            this.pResidentialinfo.TabIndex = 2;
            this.pResidentialinfo.TabStop = true;
            this.pResidentialinfo.Text = "Residential Info.";
            // 
            // checkBoxSurburb
            // 
            this.checkBoxSurburb.Location = new System.Drawing.Point(388, 53);
            this.checkBoxSurburb.Name = "checkBoxSurburb";
            this.checkBoxSurburb.Size = new System.Drawing.Size(451, 22);
            this.checkBoxSurburb.TabIndex = 25;
            this.checkBoxSurburb.Text = "Surburb/Zone Classification Not Available At The Time Of Date Captured";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(642, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(122, 15);
            this.label15.TabIndex = 24;
            this.label15.Text = "If Yes, Name Of Cell";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(393, 83);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(161, 15);
            this.label14.TabIndex = 22;
            this.label14.Text = "Surburb/Area Classification";
            // 
            // cbNameOfCell
            // 
            this.cbNameOfCell.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbNameOfCell.Items.AddRange(new object[] {
            "Abelemkpe Cell 2",
            "Abelemkpe ( Cell 16 )"});
            this.cbNameOfCell.LabelText = "";
            this.cbNameOfCell.Location = new System.Drawing.Point(642, 105);
            this.cbNameOfCell.Name = "cbNameOfCell";
            this.cbNameOfCell.Size = new System.Drawing.Size(223, 22);
            this.cbNameOfCell.TabIndex = 23;
            // 
            // cbSurburbArea
            // 
            this.cbSurburbArea.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbSurburbArea.Items.AddRange(new object[] {
            "Abelemkpe",
            "Accra Central",
            "Achimota",
            "Adenta ",
            "Ashongman Estates",
            "Awoshie",
            "Chorkor",
            "Circle",
            "Dome",
            "Dzorwulu",
            "Ebony",
            "Fish Pond",
            "Gbawe-Mallam",
            "Kasoa",
            "Kokomlemle",
            "Kotobabi",
            "Kwabenya",
            "Lapaz",
            "Legon",
            "Madina",
            "Mamprobi-Accra",
            "New Town",
            "Odorkor-Official Town",
            "Omanjor",
            "Osu",
            "Pig Farm",
            "Pokuase",
            "Taifa",
            "Teshie-Nungua",
            "West Legon"});
            this.cbSurburbArea.LabelText = "";
            this.cbSurburbArea.Location = new System.Drawing.Point(393, 105);
            this.cbSurburbArea.Name = "cbSurburbArea";
            this.cbSurburbArea.Size = new System.Drawing.Size(212, 22);
            this.cbSurburbArea.TabIndex = 22;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(12, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(119, 15);
            this.label13.TabIndex = 22;
            this.label13.Text = "Residential Address";
            // 
            // tbResidentialAddress
            // 
            this.tbResidentialAddress.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.tbResidentialAddress.LabelText = "";
            this.tbResidentialAddress.Location = new System.Drawing.Point(12, 42);
            this.tbResidentialAddress.Multiline = true;
            this.tbResidentialAddress.Name = "tbResidentialAddress";
            this.tbResidentialAddress.Size = new System.Drawing.Size(332, 84);
            this.tbResidentialAddress.TabIndex = 22;
            // 
            // pPersonalInfo
            // 
            this.pPersonalInfo.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.pPersonalInfo.Controls.Add(this.label12);
            this.pPersonalInfo.Controls.Add(this.tbTelephoneNumber);
            this.pPersonalInfo.Controls.Add(this.tbMobileNumber);
            this.pPersonalInfo.Controls.Add(this.label11);
            this.pPersonalInfo.Controls.Add(this.tbEmail);
            this.pPersonalInfo.Controls.Add(this.label10);
            this.pPersonalInfo.Controls.Add(this.checkboxUseRealAge);
            this.pPersonalInfo.Controls.Add(this.dtpDOB);
            this.pPersonalInfo.Controls.Add(this.label9);
            this.pPersonalInfo.Controls.Add(this.cbGender);
            this.pPersonalInfo.Controls.Add(this.label8);
            this.pPersonalInfo.Controls.Add(this.tbOthernames);
            this.pPersonalInfo.Controls.Add(this.label7);
            this.pPersonalInfo.Controls.Add(this.label6);
            this.pPersonalInfo.Controls.Add(this.cbMemberType);
            this.pPersonalInfo.Controls.Add(this.tbSurname);
            this.pPersonalInfo.Controls.Add(this.label5);
            this.pPersonalInfo.Dock = Wisej.Web.DockStyle.Top;
            this.pPersonalInfo.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.pPersonalInfo.HeaderForeColor = System.Drawing.Color.Black;
            this.pPersonalInfo.Location = new System.Drawing.Point(0, 114);
            this.pPersonalInfo.Name = "pPersonalInfo";
            this.pPersonalInfo.ShowHeader = true;
            this.pPersonalInfo.Size = new System.Drawing.Size(926, 234);
            this.pPersonalInfo.TabIndex = 1;
            this.pPersonalInfo.TabStop = true;
            this.pPersonalInfo.Text = "Personal Information";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(604, 138);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(89, 15);
            this.label12.TabIndex = 21;
            this.label12.Text = "Telephone No.";
            // 
            // tbTelephoneNumber
            // 
            this.tbTelephoneNumber.LabelText = "";
            this.tbTelephoneNumber.Location = new System.Drawing.Point(604, 168);
            this.tbTelephoneNumber.Name = "tbTelephoneNumber";
            this.tbTelephoneNumber.Size = new System.Drawing.Size(261, 22);
            this.tbTelephoneNumber.TabIndex = 20;
            // 
            // tbMobileNumber
            // 
            this.tbMobileNumber.LabelText = "";
            this.tbMobileNumber.Location = new System.Drawing.Point(297, 168);
            this.tbMobileNumber.Name = "tbMobileNumber";
            this.tbMobileNumber.Size = new System.Drawing.Size(261, 22);
            this.tbMobileNumber.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(297, 138);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 15);
            this.label11.TabIndex = 18;
            this.label11.Text = "Mobile No.";
            // 
            // tbEmail
            // 
            this.tbEmail.LabelText = "";
            this.tbEmail.Location = new System.Drawing.Point(604, 98);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(261, 22);
            this.tbEmail.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(604, 76);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 15);
            this.label10.TabIndex = 16;
            this.label10.Text = "Email";
            // 
            // checkboxUseRealAge
            // 
            this.checkboxUseRealAge.ForeColor = System.Drawing.Color.Black;
            this.checkboxUseRealAge.Location = new System.Drawing.Point(125, 73);
            this.checkboxUseRealAge.Name = "checkboxUseRealAge";
            this.checkboxUseRealAge.Size = new System.Drawing.Size(112, 22);
            this.checkboxUseRealAge.TabIndex = 15;
            this.checkboxUseRealAge.Text = "Use Real Age";
            // 
            // dtpDOB
            // 
            this.dtpDOB.Checked = false;
            this.dtpDOB.LabelText = "";
            this.dtpDOB.Location = new System.Drawing.Point(12, 97);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(247, 22);
            this.dtpDOB.TabIndex = 7;
            this.dtpDOB.Value = new System.DateTime(2020, 9, 4, 11, 6, 40, 118);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(12, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 15);
            this.label9.TabIndex = 14;
            this.label9.Text = "Date Of Birth";
            // 
            // cbGender
            // 
            this.cbGender.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cbGender.LabelText = "";
            this.cbGender.Location = new System.Drawing.Point(297, 97);
            this.cbGender.Name = "cbGender";
            this.cbGender.Size = new System.Drawing.Size(261, 22);
            this.cbGender.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(297, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 15);
            this.label8.TabIndex = 12;
            this.label8.Text = "Gender";
            // 
            // tbOthernames
            // 
            this.tbOthernames.LabelText = "";
            this.tbOthernames.Location = new System.Drawing.Point(604, 35);
            this.tbOthernames.Name = "tbOthernames";
            this.tbOthernames.Size = new System.Drawing.Size(261, 22);
            this.tbOthernames.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(604, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Othernames";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(297, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "Surname";
            // 
            // cbMemberType
            // 
            this.cbMemberType.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbMemberType.Items.AddRange(new object[] {
            "Visitor",
            "New Convert",
            "Want To Be a Member",
            "Rededication"});
            this.cbMemberType.LabelText = "";
            this.cbMemberType.Location = new System.Drawing.Point(12, 35);
            this.cbMemberType.Name = "cbMemberType";
            this.cbMemberType.Size = new System.Drawing.Size(247, 22);
            this.cbMemberType.TabIndex = 7;
            // 
            // tbSurname
            // 
            this.tbSurname.LabelText = "";
            this.tbSurname.Location = new System.Drawing.Point(297, 35);
            this.tbSurname.Name = "tbSurname";
            this.tbSurname.Size = new System.Drawing.Size(261, 22);
            this.tbSurname.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(12, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Member Type";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(140, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Pre-Member Data Entry";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Dock = Wisej.Web.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(950, 37);
            this.panel6.TabIndex = 7;
            this.panel6.TabStop = true;
            // 
            // toolBar1
            // 
            this.toolBar1.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnSavePreMember,
            this.btnClear,
            this.btnUpdate});
            this.toolBar1.Dock = Wisej.Web.DockStyle.Bottom;
            this.toolBar1.Location = new System.Drawing.Point(0, 456);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(950, 51);
            this.toolBar1.TabIndex = 8;
            this.toolBar1.TabStop = false;
            this.toolBar1.ButtonClick += new Wisej.Web.ToolBarButtonClickEventHandler(this.toolBar1_ButtonClick);
            // 
            // btnSavePreMember
            // 
            this.btnSavePreMember.ImageSource = "icon-save";
            this.btnSavePreMember.Name = "btnSavePreMember";
            this.btnSavePreMember.Text = "Create Pre-Member";
            this.btnSavePreMember.Click += new System.EventHandler(this.btnSavePreMember_Click);
            // 
            // btnClear
            // 
            this.btnClear.ImageSource = "icon-close";
            this.btnClear.Name = "btnClear";
            this.btnClear.Text = "Clear Screen";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Text = ">Update";
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // UCPreMember
            // 
            this.Controls.Add(this.toolBar1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Name = "UCPreMember";
            this.Size = new System.Drawing.Size(950, 507);
            this.Load += new System.EventHandler(this.UCPreMember_Load);
            this.pAttendanceInfo.ResumeLayout(false);
            this.pAttendanceInfo.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.pStudentResidentialInfo.ResumeLayout(false);
            this.pStudentResidentialInfo.PerformLayout();
            this.pEmploymentDetails.ResumeLayout(false);
            this.pEmploymentDetails.PerformLayout();
            this.pResidentialinfo.ResumeLayout(false);
            this.pResidentialinfo.PerformLayout();
            this.pPersonalInfo.ResumeLayout(false);
            this.pPersonalInfo.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Wisej.Web.Panel pAttendanceInfo;
        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel pStudentResidentialInfo;
        private Wisej.Web.Panel pEmploymentDetails;
        private Wisej.Web.Panel pResidentialinfo;
        private Wisej.Web.Panel pPersonalInfo;
        private Wisej.Web.Label label1;
        private Wisej.Web.ComboBox cbServiceAttendance;
        private Wisej.Web.ComboBox cbChurchAttendance;
        private Wisej.Web.DateTimePicker dtpattendance;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label2;
        private Wisej.Web.TextBox tbRoomNumber;
        private Wisej.Web.TextBox tbHallOfAffiliation;
        private Wisej.Web.Label label26;
        private Wisej.Web.Label label25;
        private Wisej.Web.ComboBox cbResidentOnCampus;
        private Wisej.Web.Label label24;
        private Wisej.Web.TextBox tbProgramOfStudy;
        private Wisej.Web.Label label23;
        private Wisej.Web.Label label22;
        private Wisej.Web.TextBox tblevelform;
        private Wisej.Web.Label label21;
        private Wisej.Web.ComboBox cbAcademic;
        private Wisej.Web.TextBox tbNameOfSchool;
        private Wisej.Web.Label label20;
        private Wisej.Web.TextBox tbDesignation;
        private Wisej.Web.Label label19;
        private Wisej.Web.Label label18;
        private Wisej.Web.TextBox tbBusinessAddress;
        private Wisej.Web.TextBox tbNameOfEmployer;
        private Wisej.Web.Label label17;
        private Wisej.Web.Label label16;
        private Wisej.Web.ComboBox cbEmploymentStatus;
        private Wisej.Web.CheckBox checkBoxSurburb;
        private Wisej.Web.Label label15;
        private Wisej.Web.Label label14;
        private Wisej.Web.ComboBox cbNameOfCell;
        private Wisej.Web.ComboBox cbSurburbArea;
        private Wisej.Web.Label label13;
        private Wisej.Web.TextBox tbResidentialAddress;
        private Wisej.Web.Label label12;
        private Wisej.Web.TextBox tbTelephoneNumber;
        private Wisej.Web.TextBox tbMobileNumber;
        private Wisej.Web.Label label11;
        private Wisej.Web.TextBox tbEmail;
        private Wisej.Web.Label label10;
        private Wisej.Web.CheckBox checkboxUseRealAge;
        private Wisej.Web.DateTimePicker dtpDOB;
        private Wisej.Web.Label label9;
        private Wisej.Web.ComboBox cbGender;
        private Wisej.Web.Label label8;
        private Wisej.Web.TextBox tbOthernames;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label6;
        private Wisej.Web.ComboBox cbMemberType;
        private Wisej.Web.TextBox tbSurname;
        private Wisej.Web.Label label5;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.ToolBar toolBar1;
        private Wisej.Web.ToolBarButton btnSavePreMember;
        private Wisej.Web.ToolBarButton btnClear;
        private Wisej.Web.ToolBarButton btnUpdate;
    }
}
